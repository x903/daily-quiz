-- MySQL dump 10.13  Distrib 8.0.46, for Linux (x86_64)
--
-- Host: localhost    Database: daily_quiz
-- ------------------------------------------------------
-- Server version	8.0.46

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `admin`
--

DROP TABLE IF EXISTS `admin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `admin` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'PBKDF2:sha256 哈希，不存明文',
  `role` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'admin',
  `display_name` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `status` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'active',
  `last_login_at` varchar(19) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `created_at` varchar(19) COLLATE utf8mb4_unicode_ci NOT NULL,
  `updated_at` varchar(19) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_admin_username` (`username`),
  KEY `idx_admin_status` (`status`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin`
--

LOCK TABLES `admin` WRITE;
/*!40000 ALTER TABLE `admin` DISABLE KEYS */;
INSERT INTO `admin` VALUES (1,'admin','pbkdf2:sha256:1000000$xNj9HVznOOctRklu$10221fcd6fa83a37d3e266609c5c78d4047bb06a26068b9939fa2909a3db3c8d','admin','','active','2026-11-06 23:16:00','2026-11-06 21:07:42','2026-11-06 23:16:00');
/*!40000 ALTER TABLE `admin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `admins`
--

DROP TABLE IF EXISTS `admins`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `admins` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `role` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'admin',
  `display_name` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `status` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'active',
  `last_login_at` varchar(19) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `created_at` varchar(19) COLLATE utf8mb4_unicode_ci NOT NULL,
  `updated_at` varchar(19) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_admins_username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='管理员（独立于 users）';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admins`
--

LOCK TABLES `admins` WRITE;
/*!40000 ALTER TABLE `admins` DISABLE KEYS */;
INSERT INTO `admins` VALUES (1,'admin','pbkdf2:sha256:1000000$xNj9HVznOOctRklu$10221fcd6fa83a37d3e266609c5c78d4047bb06a26068b9939fa2909a3db3c8d','admin','','active','2026-11-07 17:05:51','2026-11-06 21:07:42','2026-11-07 17:05:51');
/*!40000 ALTER TABLE `admins` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cert_categories`
--

DROP TABLE IF EXISTS `cert_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cert_categories` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `vendor_slug` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `vendor_name` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `direction_slug` varchar(48) COLLATE utf8mb4_unicode_ci NOT NULL,
  `direction_name` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `level_slug` varchar(48) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `level_name` varchar(96) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `path_slug` varchar(160) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'aliyun/acp/cloud',
  `cert_name` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL,
  `exam_code` varchar(48) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `difficulty` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `sort_order` int NOT NULL DEFAULT '0',
  `status` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'active',
  `seo_title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `seo_keywords` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `seo_description` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `created_at` varchar(19) COLLATE utf8mb4_unicode_ci NOT NULL,
  `updated_at` varchar(19) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_cat_path` (`path_slug`),
  KEY `idx_cat_vendor` (`vendor_slug`,`sort_order`),
  KEY `idx_cat_direction` (`vendor_slug`,`direction_slug`)
) ENGINE=InnoDB AUTO_INCREMENT=45 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='认证分类（三级）';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cert_categories`
--

LOCK TABLES `cert_categories` WRITE;
/*!40000 ALTER TABLE `cert_categories` DISABLE KEYS */;
INSERT INTO `cert_categories` VALUES (1,'aliyun','阿里云认证','aca','阿里云ACA','','','aliyun/aca','阿里云ACA（助理工程师）','ACA','入门',0,'active','阿里云ACA（助理工程师）题库 - 认证题库网','阿里云ACA（助理工程师）题库,阿里云ACA（助理工程师）真题,阿里云ACA刷题,阿里云认证题库','阿里云助理工程师认证，验证云计算基础概念与阿里云核心产品的使用能力。','2026-11-07 00:01:31','2026-11-07 18:14:19'),(2,'aliyun','阿里云认证','acp','阿里云ACP','cloud','云计算高级工程师','aliyun/acp/cloud','阿里云ACP云计算高级工程师','ACP-Cloud','进阶',1,'active','阿里云ACP云计算高级工程师题库 - 认证题库网','阿里云ACP云计算高级工程师题库,阿里云ACP云计算高级工程师真题,阿里云ACP刷题,阿里云认证题库','阿里云专业工程师认证，按技术方向细分，验证真实项目中的方案设计与运维能力。','2026-11-07 00:01:31','2026-11-07 18:14:19'),(3,'aliyun','阿里云认证','acp','阿里云ACP','llm','大模型高级工程师','aliyun/acp/llm','阿里云ACP大模型高级工程师','ACP-LLM','进阶',2,'active','阿里云ACP大模型高级工程师题库 - 认证题库网','阿里云ACP大模型高级工程师题库,阿里云ACP大模型高级工程师真题,阿里云ACP刷题,阿里云认证题库','阿里云专业工程师认证，按技术方向细分，验证真实项目中的方案设计与运维能力。','2026-11-07 00:01:31','2026-11-07 18:14:19'),(4,'aliyun','阿里云认证','acp','阿里云ACP','bigdata','大数据高级工程师','aliyun/acp/bigdata','阿里云ACP大数据高级工程师','ACP-BigData','进阶',3,'active','阿里云ACP大数据高级工程师题库 - 认证题库网','阿里云ACP大数据高级工程师题库,阿里云ACP大数据高级工程师真题,阿里云ACP刷题,阿里云认证题库','阿里云专业工程师认证，按技术方向细分，验证真实项目中的方案设计与运维能力。','2026-11-07 00:01:31','2026-11-07 18:14:19'),(5,'aliyun','阿里云认证','ace','阿里云ACE','architect','云计算架构师','aliyun/ace/architect','阿里云ACE云计算架构师','ACE-Architect','专家',4,'active','阿里云ACE云计算架构师题库 - 认证题库网','阿里云ACE云计算架构师题库,阿里云ACE云计算架构师真题,阿里云ACE刷题,阿里云认证题库','阿里云高级架构师认证，面向复杂企业级场景的架构设计与治理能力。','2026-11-07 00:01:31','2026-11-07 18:14:19'),(6,'huawei','华为认证','datacom','数通 Datacom','hcia','HCIA','huawei/datacom/hcia','华为HCIA-数通','H12-811','入门',5,'active','华为HCIA-数通题库 - 认证题库网','华为HCIA-数通题库,华为HCIA-数通真题,数通 Datacom刷题,华为认证题库','华为数通（Datacom）方向，覆盖企业路由交换、园区网络与广域互联。','2026-11-07 00:01:31','2026-11-07 18:14:19'),(7,'huawei','华为认证','datacom','数通 Datacom','hcip','HCIP','huawei/datacom/hcip','华为HCIP-数通','H12-821 / H12-831','进阶',6,'active','华为HCIP-数通题库 - 认证题库网','华为HCIP-数通题库,华为HCIP-数通真题,数通 Datacom刷题,华为认证题库','华为数通（Datacom）方向，覆盖企业路由交换、园区网络与广域互联。','2026-11-07 00:01:31','2026-11-07 18:14:19'),(8,'huawei','华为认证','datacom','数通 Datacom','hcie','HCIE','huawei/datacom/hcie','华为HCIE-数通','H12-891','专家',7,'active','华为HCIE-数通题库 - 认证题库网','华为HCIE-数通题库,华为HCIE-数通真题,数通 Datacom刷题,华为认证题库','华为数通（Datacom）方向，覆盖企业路由交换、园区网络与广域互联。','2026-11-07 00:01:31','2026-11-07 18:14:19'),(9,'huawei','华为认证','cloud','云计算','hcia','HCIA','huawei/cloud/hcia','华为HCIA-云计算','H13-511','入门',8,'active','华为HCIA-云计算题库 - 认证题库网','华为HCIA-云计算题库,华为HCIA-云计算真题,云计算刷题,华为认证题库','华为云计算方向，覆盖华为云平台、虚拟化、容器与云运维。','2026-11-07 00:01:31','2026-11-07 18:14:19'),(10,'huawei','华为认证','cloud','云计算','hcip','HCIP','huawei/cloud/hcip','华为HCIP-云计算','H13-521 / H13-522','进阶',9,'active','华为HCIP-云计算题库 - 认证题库网','华为HCIP-云计算题库,华为HCIP-云计算真题,云计算刷题,华为认证题库','华为云计算方向，覆盖华为云平台、虚拟化、容器与云运维。','2026-11-07 00:01:31','2026-11-07 18:14:19'),(11,'huawei','华为认证','cloud','云计算','hcie','HCIE','huawei/cloud/hcie','华为HCIE-云计算','H13-531','专家',10,'active','华为HCIE-云计算题库 - 认证题库网','华为HCIE-云计算题库,华为HCIE-云计算真题,云计算刷题,华为认证题库','华为云计算方向，覆盖华为云平台、虚拟化、容器与云运维。','2026-11-07 00:01:31','2026-11-07 18:14:19'),(12,'huawei','华为认证','security','安全','hcia','HCIA','huawei/security/hcia','华为HCIA-安全','H12-711','入门',11,'active','华为HCIA-安全题库 - 认证题库网','华为HCIA-安全题库,华为HCIA-安全真题,安全刷题,华为认证题库','华为安全方向，覆盖防火墙、VPN、入侵防御与安全运维。','2026-11-07 00:01:31','2026-11-07 18:14:19'),(13,'huawei','华为认证','security','安全','hcip','HCIP','huawei/security/hcip','华为HCIP-安全','H12-721 / H12-722','进阶',12,'active','华为HCIP-安全题库 - 认证题库网','华为HCIP-安全题库,华为HCIP-安全真题,安全刷题,华为认证题库','华为安全方向，覆盖防火墙、VPN、入侵防御与安全运维。','2026-11-07 00:01:31','2026-11-07 18:14:19'),(14,'huawei','华为认证','security','安全','hcie','HCIE','huawei/security/hcie','华为HCIE-安全','H12-731','专家',13,'active','华为HCIE-安全题库 - 认证题库网','华为HCIE-安全题库,华为HCIE-安全真题,安全刷题,华为认证题库','华为安全方向，覆盖防火墙、VPN、入侵防御与安全运维。','2026-11-07 00:01:31','2026-11-07 18:14:19'),(15,'huawei','华为认证','storage','存储','hcia','HCIA','huawei/storage/hcia','华为HCIA-存储','H13-611','入门',14,'active','华为HCIA-存储题库 - 认证题库网','华为HCIA-存储题库,华为HCIA-存储真题,存储刷题,华为认证题库','华为存储方向，覆盖闪存、分布式存储与备份容灾。','2026-11-07 00:01:31','2026-11-07 18:14:19'),(16,'huawei','华为认证','storage','存储','hcip','HCIP','huawei/storage/hcip','华为HCIP-存储','H13-621 / H13-622','进阶',15,'active','华为HCIP-存储题库 - 认证题库网','华为HCIP-存储题库,华为HCIP-存储真题,存储刷题,华为认证题库','华为存储方向，覆盖闪存、分布式存储与备份容灾。','2026-11-07 00:01:31','2026-11-07 18:14:19'),(17,'huawei','华为认证','storage','存储','hcie','HCIE','huawei/storage/hcie','华为HCIE-存储','H13-631','专家',16,'active','华为HCIE-存储题库 - 认证题库网','华为HCIE-存储题库,华为HCIE-存储真题,存储刷题,华为认证题库','华为存储方向，覆盖闪存、分布式存储与备份容灾。','2026-11-07 00:01:31','2026-11-07 18:14:19'),(18,'aws','AWS 认证','cloud-practitioner','Cloud Practitioner','','','aws/cloud-practitioner','AWS Cloud Practitioner（云从业者）','CLF-C02','入门',17,'active','AWS Cloud Practitioner（云从业者）题库 - 认证题库网','AWS Cloud Practitioner（云从业者）题库,AWS Cloud Practitioner（云从业者）真题,Cloud Practitioner刷题,AWS 认证题库','零基础入门的 AWS 云从业者认证，验证对云概念、核心服务、计费与安全的基础理解。','2026-11-07 00:01:31','2026-11-07 18:14:19'),(19,'aws','AWS 认证','solutions-architect','Solutions Architect','associate','Associate','aws/solutions-architect/associate','AWS Solutions Architect – Associate','SAA-C03','进阶',18,'active','AWS Solutions Architect – Associate题库 - 认证题库网','AWS Solutions Architect – Associate题库,AWS Solutions Architect – Associate真题,Solutions Architect刷题,AWS 认证题库','AWS 架构师方向，基于 Well-Architected 框架设计安全、高可用、可扩展、成本优化的云架构。','2026-11-07 00:01:31','2026-11-07 18:14:19'),(20,'aws','AWS 认证','solutions-architect','Solutions Architect','professional','Professional','aws/solutions-architect/professional','AWS Solutions Architect – Professional','SAP-C02','高级',19,'active','AWS Solutions Architect – Professional题库 - 认证题库网','AWS Solutions Architect – Professional题库,AWS Solutions Architect – Professional真题,Solutions Architect刷题,AWS 认证题库','AWS 架构师方向，基于 Well-Architected 框架设计安全、高可用、可扩展、成本优化的云架构。','2026-11-07 00:01:31','2026-11-07 18:14:19'),(21,'aws','AWS 认证','developer','Developer','','','aws/developer','AWS Developer – Associate','DVA-C02','进阶',20,'active','AWS Developer – Associate题库 - 认证题库网','AWS Developer – Associate题库,AWS Developer – Associate真题,Developer刷题,AWS 认证题库','面向应用开发者，考察在 AWS 上开发、部署与调试云原生应用的能力。','2026-11-07 00:01:31','2026-11-07 18:14:19'),(22,'aws','AWS 认证','sysops','SysOps Administrator','','','aws/sysops','AWS SysOps Administrator – Associate','SOA-C02','进阶',21,'active','AWS SysOps Administrator – Associate题库 - 认证题库网','AWS SysOps Administrator – Associate题库,AWS SysOps Administrator – Associate真题,SysOps Administrator刷题,AWS 认证题库','面向云运维人员，考察 AWS 环境的部署、监控、自动化与故障处理能力。','2026-11-07 00:01:31','2026-11-07 18:14:19'),(23,'aws','AWS 认证','devops','DevOps Engineer','','','aws/devops','AWS DevOps Engineer – Professional','DOP-C02','高级',22,'active','AWS DevOps Engineer – Professional题库 - 认证题库网','AWS DevOps Engineer – Professional题库,AWS DevOps Engineer – Professional真题,DevOps Engineer刷题,AWS 认证题库','AWS 专业级 DevOps 认证，考察持续交付、自动化编排、监控告警与安全合规能力。','2026-11-07 00:01:31','2026-11-07 18:14:19'),(24,'aws','AWS 认证','security','Security','','','aws/security','AWS Security – Specialty','SCS-C02','高级',23,'active','AWS Security – Specialty题库 - 认证题库网','AWS Security – Specialty题库,AWS Security – Specialty真题,Security刷题,AWS 认证题库','AWS 安全专项认证，考察身份权限、数据保护、检测响应与合规治理能力。','2026-11-07 00:01:31','2026-11-07 18:14:19'),(25,'aws','AWS 认证','machine-learning','Machine Learning','','','aws/machine-learning','AWS Machine Learning – Specialty','MLA-C01','高级',24,'active','AWS Machine Learning – Specialty题库 - 认证题库网','AWS Machine Learning – Specialty题库,AWS Machine Learning – Specialty真题,Machine Learning刷题,AWS 认证题库','AWS 机器学习专项认证，考察数据准备、模型训练、部署与 MLOps 能力。','2026-11-07 00:01:31','2026-11-07 18:14:19'),(26,'cisco','思科认证','ccna','CCNA','','','cisco/ccna','思科CCNA','200-301','入门',25,'active','思科CCNA题库 - 认证题库网','思科CCNA题库,思科CCNA真题,CCNA刷题,思科认证题库','思科初级网络工程师认证，验证网络基础、IP 连接、安全基础与自动化认知。','2026-11-07 00:01:31','2026-11-07 18:14:19'),(27,'cisco','思科认证','ccnp','CCNP','enterprise','Enterprise','cisco/ccnp/enterprise','思科CCNP Enterprise','350-401 ENCOR','高级',26,'active','思科CCNP Enterprise题库 - 认证题库网','思科CCNP Enterprise题库,思科CCNP Enterprise真题,CCNP刷题,思科认证题库','思科专业级认证，覆盖企业网络、安全、数据中心与服务提供商方向。','2026-11-07 00:01:31','2026-11-07 18:14:19'),(28,'cisco','思科认证','ccnp','CCNP','security','Security','cisco/ccnp/security','思科CCNP Security','350-701 SCOR','高级',27,'active','思科CCNP Security题库 - 认证题库网','思科CCNP Security题库,思科CCNP Security真题,CCNP刷题,思科认证题库','思科专业级认证，覆盖企业网络、安全、数据中心与服务提供商方向。','2026-11-07 00:01:31','2026-11-07 18:14:19'),(29,'cisco','思科认证','ccnp','CCNP','data-center','Data Center','cisco/ccnp/data-center','思科CCNP Data Center','350-601 DCCOR','高级',28,'active','思科CCNP Data Center题库 - 认证题库网','思科CCNP Data Center题库,思科CCNP Data Center真题,CCNP刷题,思科认证题库','思科专业级认证，覆盖企业网络、安全、数据中心与服务提供商方向。','2026-11-07 00:01:31','2026-11-07 18:14:19'),(30,'cisco','思科认证','ccnp','CCNP','service-provider','Service Provider','cisco/ccnp/service-provider','思科CCNP Service Provider','350-501 SPCOR','高级',29,'active','思科CCNP Service Provider题库 - 认证题库网','思科CCNP Service Provider题库,思科CCNP Service Provider真题,CCNP刷题,思科认证题库','思科专业级认证，覆盖企业网络、安全、数据中心与服务提供商方向。','2026-11-07 00:01:31','2026-11-07 18:14:19'),(31,'cisco','思科认证','ccie','CCIE','enterprise','Enterprise','cisco/ccie/enterprise','思科CCIE Enterprise','400-007 + LAB','专家',30,'active','思科CCIE Enterprise题库 - 认证题库网','思科CCIE Enterprise题库,思科CCIE Enterprise真题,CCIE刷题,思科认证题库','思科专家级认证，笔试 + 8 小时实验考试，考察大规模复杂网络的设计、部署与排障。','2026-11-07 00:01:31','2026-11-07 18:14:19'),(32,'cisco','思科认证','ccie','CCIE','security','Security','cisco/ccie/security','思科CCIE Security','400-251 + LAB','专家',31,'active','思科CCIE Security题库 - 认证题库网','思科CCIE Security题库,思科CCIE Security真题,CCIE刷题,思科认证题库','思科专家级认证，笔试 + 8 小时实验考试，考察大规模复杂网络的设计、部署与排障。','2026-11-07 00:01:31','2026-11-07 18:14:19'),(33,'cisco','思科认证','ccie','CCIE','data-center','Data Center','cisco/ccie/data-center','思科CCIE Data Center','400-080 + LAB','专家',32,'active','思科CCIE Data Center题库 - 认证题库网','思科CCIE Data Center题库,思科CCIE Data Center真题,CCIE刷题,思科认证题库','思科专家级认证，笔试 + 8 小时实验考试，考察大规模复杂网络的设计、部署与排障。','2026-11-07 00:01:31','2026-11-07 18:14:19'),(34,'cisco','思科认证','ccie','CCIE','service-provider','Service Provider','cisco/ccie/service-provider','思科CCIE Service Provider','400-201 + LAB','专家',33,'active','思科CCIE Service Provider题库 - 认证题库网','思科CCIE Service Provider题库,思科CCIE Service Provider真题,CCIE刷题,思科认证题库','思科专家级认证，笔试 + 8 小时实验考试，考察大规模复杂网络的设计、部署与排障。','2026-11-07 00:01:31','2026-11-07 18:14:19');
/*!40000 ALTER TABLE `cert_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cert_intro`
--

DROP TABLE IF EXISTS `cert_intro`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cert_intro` (
  `id` int unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `slug` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '三级菜单节点 slug，唯一',
  `cert_name` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '认证名称（后台可搜索）',
  `vendor` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '一级厂商',
  `direction` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '二级方向',
  `level` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '三级等级 / 考试代码',
  `intro` text COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '百科介绍正文（管理员可编辑）',
  `source` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '资料来源',
  `is_preset` tinyint(1) NOT NULL DEFAULT '1' COMMENT '1=系统预置',
  `updated_by` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '最后修改人',
  `created_at` varchar(19) COLLATE utf8mb4_unicode_ci NOT NULL,
  `updated_at` varchar(19) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_cert_intro_slug` (`slug`),
  KEY `idx_cert_intro_vendor` (`vendor`),
  KEY `idx_cert_intro_name` (`cert_name`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='认证百科介绍（CMS 可编辑）';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cert_intro`
--

LOCK TABLES `cert_intro` WRITE;
/*!40000 ALTER TABLE `cert_intro` DISABLE KEYS */;
INSERT INTO `cert_intro` VALUES (1,'hcip-datacom','HCIP-数通','华为认证','数通','HCIP','华为HCIP数通属于中级专业认证。它代表具备独立规划、调试中小型企业网络及处理真实场景问题的能力，是企业网络运维、系统集成等岗位的核心敲门砖，也是通往高级专家HCIE的重要跳板。','华为人才在线 · HCIP-Datacom（H12-821 / H12-831）',1,'','2026-11-06 22:49:10',''),(2,'hcip-cloud','HCIP-云计算','华为认证','云计算','HCIP','聚焦华为云平台部署、虚拟化技术、容器技术、云资源调度与云容灾备份等核心内容。随着企业全面上云，它是云计算运维工程师、云解决方案工程师的高薪核心证书。','华为人才在线 · HCIP-Cloud Computing',1,'','2026-11-06 22:49:10',''),(3,'hcip-security','HCIP-安全','华为认证','安全 / 存储方向','HCIP','华为 HCIP-Security 是安全方向的中级认证，面向具备网络安全基础的工程师，覆盖防火墙高可靠性、VPN、入侵防御、终端与云安全、安全运维等内容，证明持证人具备大中型企业网络安全架构的设计、部署与运维能力，是安全工程师与等保相关岗位的重要资质。','华为人才在线 · HCIP-Security / 华为认证方向百科',1,'','2026-11-06 22:49:10',''),(4,'hcip-storage','HCIP-存储','华为认证','安全 / 存储方向','HCIP','华为 HCIP-Storage 是存储方向的中级认证，考核闪存与分布式存储系统的规划设计、部署实施、性能调优、日常运维与故障处理，覆盖 RAID、SAN/NAS、备份容灾等核心技术，适合存储工程师与数据中心运维岗位。','华为企业业务 · HCIP-Storage V5.5（e.huawei.com）',1,'','2026-11-06 22:49:10',''),(5,'aws-solutions-architect','Solutions Architect (解决方案架构师)','AWS 认证','架构设计','Associate / SAA-C03','主要考核如何基于 AWS Well-Architected Framework，设计安全、弹性、高性能且成本优化的云架构。是亚马逊云科技认可度极高、全球通用的黄金架构师证书。','AWS 官方考试指南 · Solutions Architect - Associate (SAA-C03)',1,'','2026-11-06 22:49:10',''),(6,'aws-cloud-practitioner','Cloud Practitioner (云从业者)','AWS 认证','云基础','Foundational / CLF-C02','零基础入云的入门级认证。不要求深入的技术背景，重点验证对AWS云服务、核心架构和高阶术语的基础理解，是转行云职业的最佳起点。','AWS 官方考试指南 · Cloud Practitioner (CLF-C02)',1,'','2026-11-06 22:49:10',''),(7,'aws-devops-engineer','DevOps Engineer (运维/DevOps工程师)','AWS 认证','DevOps','Professional / DOP-C02','AWS Certified DevOps Engineer - Professional（DOP-C02）是专业级认证，面向具有两年以上 AWS 经验的 DevOps 工程师，考核在 AWS 上预置、运行和管理分布式应用系统的能力，涵盖持续交付、自动化编排、监控告警、安全合规与高可用架构，是云运维 / DevOps 路线的进阶证书。','AWS 官方考试指南 · DevOps Engineer - Professional (DOP-C02)',1,'','2026-11-06 22:49:10',''),(8,'ccna','CCNA (网络工程师)','思科认证','网络基础','Associate / 200-301','IT网络行业的基石认证。全面考察网络基础、IP连接性、IP服务、安全基础和自动化编程，证明持证人具备配置、运维中小型网络的能力。','Cisco U. · CCNA (200-301)',1,'','2026-11-06 22:49:10',''),(9,'ccnp','CCNP (高级网络工程师)','思科认证','企业网络','Professional / CCNP Enterprise','面向有经验的技术人员，深入考察企业级复杂网络的设计、实施和故障排除，是企业内部高级网络架构师的进阶必备证书。','Cisco U. · CCNP Enterprise (ENCORE 350-401)',1,'','2026-11-06 22:49:10','');
/*!40000 ALTER TABLE `cert_intro` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cert_intros`
--

DROP TABLE IF EXISTS `cert_intros`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cert_intros` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `category_id` int unsigned NOT NULL,
  `positioning` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `audience` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `exam_topics` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `difficulty` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `advice` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `summary` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `source` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `updated_by` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `created_at` varchar(19) COLLATE utf8mb4_unicode_ci NOT NULL,
  `updated_at` varchar(19) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_intro_category` (`category_id`),
  CONSTRAINT `fk_intro_category` FOREIGN KEY (`category_id`) REFERENCES `cert_categories` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=45 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='认证介绍（五段式）';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cert_intros`
--

LOCK TABLES `cert_intros` WRITE;
/*!40000 ALTER TABLE `cert_intros` DISABLE KEYS */;
INSERT INTO `cert_intros` VALUES (1,1,'阿里云助理工程师认证，验证云计算基础概念与阿里云核心产品的使用能力。','在校学生、云计算初学者、准备转行云计算的从业者。','云计算基础、ECS 云服务器、OSS 对象存储、RDS 数据库、SLB 负载均衡、云安全基础。','入门','先建立云产品全景图，再逐项动手开通与配置；配套 300 道基础题即可覆盖大部分考点。','阿里云助理工程师认证，验证云计算基础概念与阿里云核心产品的使用能力。','','','2026-11-07 00:01:31','2026-11-07 00:01:31'),(2,2,'面向使用阿里云云计算产品的架构、开发、运维人员，覆盖 ECS、VPC、SLB、OSS、RDS、云监控、云上安全与高可用架构等内容。','使用阿里云产品的架构、开发、运维人员，具备一年以上云上实践经验。','ECS 实例与弹性伸缩、VPC 网络规划、SLB 负载均衡、OSS 存储与 CDN、RDS 数据库、云监控与日志、云上安全与高可用架构。','进阶','以官方考试大纲为纲，重点吃透 VPC 网络规划、高可用架构与故障排查；建议按方向刷题 500 题以上。','阿里云专业工程师认证，按技术方向细分，验证真实项目中的方案设计与运维能力。','','','2026-11-07 00:01:31','2026-11-07 00:18:27'),(3,3,'面向大模型应用开发与落地人员，考察通义千问系列模型调用、提示词工程、RAG 检索增强、模型微调与 AI 应用工程化能力。','AI 应用开发者、算法工程师、希望把大模型接入业务的技术负责人。','大模型基础、提示词工程、RAG 与向量检索、模型微调、Agent 编排、百炼平台与 AI 应用工程化。','进阶','先用百炼跑通一条 RAG 链路，再补提示词与微调理论；重点练「场景选型 + 成本控制」类题目。','阿里云专业工程师认证，按技术方向细分，验证真实项目中的方案设计与运维能力。','','','2026-11-07 00:01:31','2026-11-07 00:01:31'),(4,4,'面向大数据平台建设与数据分析人员，考察 MaxCompute、DataWorks、实时计算与数据治理能力。','大数据开发工程师、数据仓库工程师、数据平台运维人员。','MaxCompute、DataWorks 数据集成与调度、Flink 实时计算、Hologres、数据建模与数据治理。','进阶','以一条「采集 → 入湖 → 建模 → 指标」的完整链路为主线练习，理解计算与存储分离的选型逻辑。','阿里云专业工程师认证，按技术方向细分，验证真实项目中的方案设计与运维能力。','','','2026-11-07 00:01:31','2026-11-07 00:01:31'),(5,5,'面向资深云架构师和解决方案架构师，考察企业级弹性架构、云原生、混合云、容灾、安全治理等复杂场景设计能力。','资深云架构师、解决方案架构师、技术负责人。','企业级弹性架构、云原生与容器化、混合云与多活、容灾与备份、安全治理与合规、成本优化与架构演进。','专家','按「业务目标 → 架构取舍 → 风险与成本」三段式训练答题结构，配合真实案例做架构评审。','阿里云高级架构师认证，面向复杂企业级场景的架构设计与治理能力。','','','2026-11-07 00:01:31','2026-11-07 00:01:31'),(6,6,'华为数通入门级认证，验证中小型网络的配置、调试与基础排障能力。','企业网络运维、系统集成、网络规划工程师。','TCP/IP 基础、VLAN 与交换、静态路由、OSPF 基础、ACL 与 NAT、网络管理。','入门','以 eNSP 实验为主，先把 VLAN 互通、静态路由、OSPF 单区域配熟，再刷 300 道基础题。','华为数通（Datacom）方向，覆盖企业路由交换、园区网络与广域互联。','','','2026-11-07 00:01:31','2026-11-07 00:01:31'),(7,7,'面向具备中小型企业网络规划与运维能力的工程师，重点考察路由交换、BGP、MPLS VPN、SD-WAN、故障排查等能力。','企业网络运维、系统集成、网络规划工程师。','OSPF 多区域与高级特性、IS-IS、BGP 选路与策略、MPLS VPN、VXLAN、SD-WAN、网络割接与故障排查。','进阶','按「协议原理 → 拓扑实验 → 故障现象 → 定位思路」四步练；BGP 选路与 MPLS VPN 是高频难点。','华为数通（Datacom）方向，覆盖企业路由交换、园区网络与广域互联。','','','2026-11-07 00:01:31','2026-11-07 00:01:31'),(8,8,'华为数通专家级认证，考察大型园区与骨干网络的设计、部署、优化与复杂故障处理能力。','企业网络运维、系统集成、网络规划工程师。','大型网络架构设计、BGP/MPLS 高级特性、VXLAN EVPN、网络自动化、端到端故障定位、方案与实验考试。','专家','以完整园区/骨干项目为主线做设计与排障演练，实验考试要练到「看到现象能列出排查树」。','华为数通（Datacom）方向，覆盖企业路由交换、园区网络与广域互联。','','','2026-11-07 00:01:31','2026-11-07 00:01:31'),(9,9,'华为云计算入门级认证，验证云平台基础操作与虚拟化概念。','云运维工程师、云解决方案工程师、数据中心运维人员。','云计算基础、虚拟化技术、FusionCompute 操作、云存储与云网络基础。','入门','先把虚拟机创建、迁移、快照等基础操作练熟，再理解计算/存储/网络虚拟化的分层。','华为云计算方向，覆盖华为云平台、虚拟化、容器与云运维。','','','2026-11-07 00:01:31','2026-11-07 00:01:31'),(10,10,'面向云平台部署与运维工程师，考察华为云平台的规划、部署、资源调度与容灾能力。','云运维工程师、云解决方案工程师、数据中心运维人员。','云平台规划部署、虚拟化高级特性、容器与 Kubernetes、资源调度、备份容灾、云运维与监控。','进阶','按「部署 → 扩容 → 迁移 → 容灾」完整链路做实验，容器部分重点掌握 K8s 核心对象。','华为云计算方向，覆盖华为云平台、虚拟化、容器与云运维。','','','2026-11-07 00:01:31','2026-11-07 00:01:31'),(11,11,'华为云计算专家级认证，考察大型云数据中心的设计、迁移与运维治理能力。','云运维工程师、云解决方案工程师、数据中心运维人员。','云数据中心架构、多集群管理、云原生平台、迁移方案、容灾双活、性能调优与故障处理。','专家','以「业务上云迁移」为主线准备方案设计与面试答辩，重点训练取舍与风险控制表达。','华为云计算方向，覆盖华为云平台、虚拟化、容器与云运维。','','','2026-11-07 00:01:31','2026-11-07 00:01:31'),(12,12,'华为安全入门级认证，验证网络安全基础与防火墙基本配置能力。','网络安全工程师、等保建设与安全运维人员。','网络安全基础、防火墙策略、NAT、VPN 基础、终端安全基础。','入门','先把安全区域、策略匹配、NAT 与基础 VPN 配通，再补常见攻击与防护原理。','华为安全方向，覆盖防火墙、VPN、入侵防御与安全运维。','','','2026-11-07 00:01:31','2026-11-07 00:01:31'),(13,13,'面向具备网络安全基础的工程师，覆盖防火墙高可靠性、VPN、入侵防御、终端与云安全、安全运维等内容。','网络安全工程师、等保建设与安全运维人员。','防火墙双机热备、IPsec/SSL VPN、入侵防御与反病毒、终端与云安全、安全运维与等保合规。','进阶','重点练双机热备切换与 IPsec VPN 排障；入侵防御部分理解签名匹配与响应动作。','华为安全方向，覆盖防火墙、VPN、入侵防御与安全运维。','','','2026-11-07 00:01:31','2026-11-07 00:01:31'),(14,14,'华为安全专家级认证，考察大型企业安全架构设计、威胁治理与应急响应能力。','网络安全工程师、等保建设与安全运维人员。','企业安全架构、零信任、云安全治理、高级威胁防护、安全运营中心、应急响应。','专家','按「资产 → 威胁 → 架构 → 运营」搭建知识体系，准备时多练安全方案设计与事件复盘。','华为安全方向，覆盖防火墙、VPN、入侵防御与安全运维。','','','2026-11-07 00:01:31','2026-11-07 00:01:31'),(15,15,'华为存储入门级认证，验证存储基础概念与设备基本操作。','存储工程师、数据中心运维、容灾方案设计人员。','存储基础、RAID 技术、SAN/NAS 组网、OceanStor 基础配置。','入门','先把 RAID 级别与容量计算练熟，再理解 SAN 与 NAS 的适用场景差异。','华为存储方向，覆盖闪存、分布式存储与备份容灾。','','','2026-11-07 00:01:31','2026-11-07 00:01:31'),(16,16,'面向存储规划、部署与运维工程师，考察闪存与分布式存储的方案设计、性能调优与故障处理能力。','存储工程师、数据中心运维、容灾方案设计人员。','闪存存储、分布式存储、SAN/NAS 规划、双活与备份容灾、性能调优、故障处理。','进阶','以「容量规划 → 组网 → 双活 → 扩容」为主线做实验，重点理解性能瓶颈的定位方法。','华为存储方向，覆盖闪存、分布式存储与备份容灾。','','','2026-11-07 00:01:31','2026-11-07 00:01:31'),(17,17,'华为存储专家级认证，考察大型数据中心存储架构设计、容灾与数据治理能力。','存储工程师、数据中心运维、容灾方案设计人员。','数据中心存储架构、双活与两地三中心、分布式存储、数据保护、性能与容量治理。','专家','围绕「两地三中心」做方案设计演练，重点训练 RPO/RTO 目标下的架构取舍。','华为存储方向，覆盖闪存、分布式存储与备份容灾。','','','2026-11-07 00:01:31','2026-11-07 00:01:31'),(18,18,'零基础入门的 AWS 云从业者认证，验证对云概念、核心服务、计费与安全的基础理解。','云计算初学者、销售/售前/项目管理等非技术岗位、准备转行云职业的人。','云概念、核心服务（EC2/S3/VPC/RDS）、安全与合规、计费与支持计划。','入门','先过一遍 AWS Cloud Practitioner Essentials，再用 300 道模拟题查漏补缺。','零基础入门的 AWS 云从业者认证，验证对云概念、核心服务、计费与安全的基础理解。','','','2026-11-07 00:01:31','2026-11-07 00:01:31'),(19,19,'面向云架构师，考察如何基于 AWS 设计安全、高可用、可扩展、成本优化的云架构。','云架构师、解决方案顾问、后端与运维工程师。','VPC 与混合网络、EC2/ECS/Lambda 选型、S3 与存储分层、RDS/Aurora/DynamoDB、ELB 与 Auto Scaling、IAM 与 KMS、成本优化与 Well-Architected 六支柱。','进阶','把「高可用、解耦、弹性、成本」四个关键词落到每道题的方案对比上；建议刷 600 题以上并整理错题。','AWS 架构师方向，基于 Well-Architected 框架设计安全、高可用、可扩展、成本优化的云架构。','','','2026-11-07 00:01:31','2026-11-07 00:01:31'),(20,20,'AWS 架构师专家级认证，考察复杂企业架构、迁移、多账号治理与成本优化能力。','云架构师、解决方案顾问、后端与运维工程师。','多账号与 Organizations、复杂网络互联、迁移策略、混合云、灾难恢复、安全治理、成本与性能优化。','高级','以「大型企业上云」案例串起知识点，重点训练跨账号网络与迁移方案的权衡。','AWS 架构师方向，基于 Well-Architected 框架设计安全、高可用、可扩展、成本优化的云架构。','','','2026-11-07 00:01:31','2026-11-07 00:01:31'),(21,21,'面向应用开发者，考察在 AWS 上开发、部署与调试云原生应用的能力。','后端开发工程师、全栈工程师、DevOps 转型开发者。','Lambda、API Gateway、DynamoDB、S3、SQS/SNS、CI/CD、IAM 与 Secrets Manager、开发调试与可观测性。','进阶','以「一个 Serverless 应用从开发到上线」为主线，重点掌握 Lambda 权限模型与异步调用。','面向应用开发者，考察在 AWS 上开发、部署与调试云原生应用的能力。','','','2026-11-07 00:01:31','2026-11-07 00:01:31'),(22,22,'面向云运维人员，考察 AWS 环境的部署、监控、自动化与故障处理能力。','云运维工程师、SRE、系统管理员。','CloudWatch 监控告警、CloudFormation 自动化、备份与恢复、网络排障、成本与合规、Systems Manager。','进阶','重点练 CloudWatch 指标/日志/告警组合与自动化修复；排障题按「现象 → 指标 → 根因」作答。','面向云运维人员，考察 AWS 环境的部署、监控、自动化与故障处理能力。','','','2026-11-07 00:01:31','2026-11-07 00:01:31'),(23,23,'AWS 专业级 DevOps 认证，考察持续交付、自动化编排、监控告警与安全合规能力。','DevOps 工程师、SRE、平台工程师。','CodePipeline/CodeBuild/CodeDeploy、基础设施即代码、蓝绿与金丝雀发布、监控告警、事件响应、安全合规自动化。','高级','把「发布流水线 + 回滚策略 + 监控闭环」做成一个可复述的方案模板，考试中直接套用。','AWS 专业级 DevOps 认证，考察持续交付、自动化编排、监控告警与安全合规能力。','','','2026-11-07 00:01:31','2026-11-07 00:01:31'),(24,24,'AWS 安全专项认证，考察身份权限、数据保护、检测响应与合规治理能力。','安全工程师、云安全架构师、合规与审计人员。','IAM 与权限边界、KMS 与加密、WAF/Shield、GuardDuty/Security Hub、日志审计、事件响应与合规。','高级','把 IAM 策略评估逻辑（显式拒绝 > 允许）练到条件反射，再补检测与响应服务组合。','AWS 安全专项认证，考察身份权限、数据保护、检测响应与合规治理能力。','','','2026-11-07 00:01:31','2026-11-07 00:01:31'),(25,25,'AWS 机器学习专项认证，考察数据准备、模型训练、部署与 MLOps 能力。','算法工程师、数据科学家、ML 平台工程师。','SageMaker 全流程、特征工程、模型训练与调优、推理部署、MLOps 流水线、数据治理与成本优化。','高级','围绕 SageMaker 把「数据 → 训练 → 部署 → 监控」跑通一遍，重点记服务选型边界。','AWS 机器学习专项认证，考察数据准备、模型训练、部署与 MLOps 能力。','','','2026-11-07 00:01:31','2026-11-07 00:01:31'),(26,26,'思科初级网络工程师认证，验证网络基础、IP 连接、安全基础与自动化认知。','初级网络工程师、网络运维、准备进入网络行业的转行者。','网络基础、IP 连接与子网、VLAN 与交换、OSPF、安全基础、自动化与可编程性。','入门','先用 Packet Tracer 把 VLAN、静态路由、OSPF、ACL/NAT 配熟，再刷 400 道题巩固。','思科初级网络工程师认证，验证网络基础、IP 连接、安全基础与自动化认知。','','','2026-11-07 00:01:31','2026-11-07 00:01:31'),(27,27,'面向高级网络工程师，考察企业网络的设计、实施、优化和故障排除能力。','高级网络工程师、网络架构师、系统集成工程师。','双栈架构、虚拟化与 SD-WAN、BGP 与组播、QoS、网络保障与安全、自动化。','高级','以企业园区 + 分支互联为主线，练熟 OSPF/BGP/组播与 SD-WAN 方案对比。','思科专业级认证，覆盖企业网络、安全、数据中心与服务提供商方向。','','','2026-11-07 00:01:31','2026-11-07 00:01:31'),(28,28,'面向网络安全工程师，考察企业安全架构、防火墙、VPN、云安全与威胁防御能力。','高级网络工程师、网络架构师、系统集成工程师。','网络安全架构、Firepower、VPN、身份与访问、云安全、端点与威胁防御。','高级','以「边界 → 内网 → 云」三层防护为主线整理方案，重点记各安全组件的部署位置。','思科专业级认证，覆盖企业网络、安全、数据中心与服务提供商方向。','','','2026-11-07 00:01:31','2026-11-07 00:01:31'),(29,29,'面向数据中心网络工程师，考察 Nexus、ACI、VXLAN EVPN 与存储网络能力。','高级网络工程师、网络架构师、系统集成工程师。','Nexus 架构、VXLAN EVPN、ACI、SAN/NAS、自动化与编排。','高级','重点掌握 VXLAN EVPN 转发流程与 ACI 策略模型，配合模拟器做端到端打通实验。','思科专业级认证，覆盖企业网络、安全、数据中心与服务提供商方向。','','','2026-11-07 00:01:31','2026-11-07 00:01:31'),(30,30,'面向运营商网络工程师，考察 MPLS、BGP 大规模路由与段路由能力。','高级网络工程师、网络架构师、系统集成工程师。','IGP/BGP 大规模部署、MPLS L3VPN、Segment Routing、QoS、运营商自动化。','高级','以「城域 + 骨干」拓扑练 BGP 选路与 MPLS VPN，理解 SR 与 LDP 的差异。','思科专业级认证，覆盖企业网络、安全、数据中心与服务提供商方向。','','','2026-11-07 00:01:31','2026-11-07 00:01:31'),(31,31,'面向网络专家，考察大规模复杂企业网络的设计、部署、排障和优化能力。','网络专家、架构师、大型项目技术负责人。','企业架构设计、双栈与 SD-WAN、BGP/组播/QoS、网络保障、自动化、实验排障。','专家','先过笔试建立设计视角，再把 8 小时实验拆成模块反复计时训练。','思科专家级认证，笔试 + 8 小时实验考试，考察大规模复杂网络的设计、部署与排障。','','','2026-11-07 00:01:31','2026-11-07 00:01:31'),(32,32,'面向安全专家，考察大型企业安全架构的设计、部署与复杂事件处置能力。','网络专家、架构师、大型项目技术负责人。','安全架构、防火墙与 VPN、身份服务、云与数据中心安全、威胁防御、实验排障。','专家','以攻防视角串联各安全组件，实验部分重点练策略冲突与故障定位。','思科专家级认证，笔试 + 8 小时实验考试，考察大规模复杂网络的设计、部署与排障。','','','2026-11-07 00:01:31','2026-11-07 00:01:31'),(33,33,'面向数据中心专家，考察大规模数据中心网络与 ACI/VXLAN 的设计与运维能力。','网络专家、架构师、大型项目技术负责人。','数据中心架构、VXLAN EVPN、ACI、存储网络、自动化编排、实验排障。','专家','把 ACI 与 EVPN 的转发与控制面流程画成图，实验按租户→策略→外部互联逐层搭。','思科专家级认证，笔试 + 8 小时实验考试，考察大规模复杂网络的设计、部署与排障。','','','2026-11-07 00:01:31','2026-11-07 00:01:31'),(34,34,'面向运营商专家，考察大规模 SP 网络的设计、部署、排障与优化能力。','网络专家、架构师、大型项目技术负责人。','大规模 IGP/BGP、MPLS、Segment Routing、组播 VPN、QoS、运营商自动化。','专家','以运营商骨干拓扑为主线，重点练 BGP 策略与 MPLS 业务的端到端验证。','思科专家级认证，笔试 + 8 小时实验考试，考察大规模复杂网络的设计、部署与排障。','','','2026-11-07 00:01:31','2026-11-07 00:01:31');
/*!40000 ALTER TABLE `cert_intros` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `daily_records`
--

DROP TABLE IF EXISTS `daily_records`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `daily_records` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `daily_set_id` int unsigned NOT NULL,
  `user_id` int unsigned NOT NULL DEFAULT '0',
  `total` int NOT NULL,
  `correct` int NOT NULL,
  `wrong` int NOT NULL,
  `accuracy` double NOT NULL,
  `duration` int NOT NULL,
  `finished_at` varchar(19) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_records_set_user` (`daily_set_id`,`user_id`),
  KEY `idx_records_user` (`user_id`),
  CONSTRAINT `fk_records_set` FOREIGN KEY (`daily_set_id`) REFERENCES `daily_sets` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_records_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `daily_records`
--

LOCK TABLES `daily_records` WRITE;
/*!40000 ALTER TABLE `daily_records` DISABLE KEYS */;
/*!40000 ALTER TABLE `daily_records` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `daily_sets`
--

DROP TABLE IF EXISTS `daily_sets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `daily_sets` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `date` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `total_sets` int NOT NULL DEFAULT '0',
  `status` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `created_at` varchar(19) COLLATE utf8mb4_unicode_ci NOT NULL,
  `category_slug` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `category_path` varchar(512) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_daily_sets_date` (`date`),
  KEY `idx_daily_sets_category` (`category_slug`)
) ENGINE=InnoDB AUTO_INCREMENT=51 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `daily_sets`
--

LOCK TABLES `daily_sets` WRITE;
/*!40000 ALTER TABLE `daily_sets` DISABLE KEYS */;
/*!40000 ALTER TABLE `daily_sets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `email_tokens`
--

DROP TABLE IF EXISTS `email_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `email_tokens` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int unsigned NOT NULL,
  `email` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL,
  `purpose` varchar(24) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'bind_email / reset_password',
  `code_hash` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `token_hash` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `expires_at` varchar(19) COLLATE utf8mb4_unicode_ci NOT NULL,
  `attempts` int NOT NULL DEFAULT '0',
  `used` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` varchar(19) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_email_user` (`user_id`,`purpose`,`created_at`),
  KEY `idx_email_target` (`email`,`purpose`,`created_at`),
  CONSTRAINT `fk_email_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='邮箱验证码与重置 Token';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `email_tokens`
--

LOCK TABLES `email_tokens` WRITE;
/*!40000 ALTER TABLE `email_tokens` DISABLE KEYS */;
INSERT INTO `email_tokens` VALUES (3,2,'user@example.com','bind_email','8db5d5dfe4a37cf6c74e2ec579da02531b2b740033b31af9e99bc387b0450f7b','','2026-11-07 13:12:40',0,1,'2026-11-07 13:02:40'),(4,2,'user@example.com','reset_password','','e012941e1b56ad6cbc9a3bd2dcfdb323f649d93061ac60d46a530956a099dc1a','2026-11-07 13:33:14',0,0,'2026-11-07 13:03:14'),(7,2,'user@example.com','reset_password','','51851b85cecca40307da9215399e5b4b7b179a518f1103fa49a62c3ea71d30ce','2026-11-07 13:37:41',0,0,'2026-11-07 13:07:41');
/*!40000 ALTER TABLE `email_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `points_ledger`
--

DROP TABLE IF EXISTS `points_ledger`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `points_ledger` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int unsigned NOT NULL,
  `daily_set_id` int unsigned NOT NULL,
  `record_id` int unsigned DEFAULT NULL,
  `earned_date` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `set_date` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `points` int NOT NULL DEFAULT '0',
  `correct` int NOT NULL DEFAULT '0',
  `total` int NOT NULL DEFAULT '0',
  `source` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'quiz',
  `created_at` varchar(19) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_points_user_date` (`user_id`,`earned_date`),
  KEY `idx_points_date` (`earned_date`),
  KEY `idx_points_record` (`record_id`),
  KEY `fk_points_set` (`daily_set_id`),
  CONSTRAINT `fk_points_set` FOREIGN KEY (`daily_set_id`) REFERENCES `daily_sets` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_points_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `points_ledger`
--

LOCK TABLES `points_ledger` WRITE;
/*!40000 ALTER TABLE `points_ledger` DISABLE KEYS */;
/*!40000 ALTER TABLE `points_ledger` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `questions`
--

DROP TABLE IF EXISTS `questions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `questions` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `daily_set_id` int unsigned DEFAULT NULL,
  `set_index` int NOT NULL,
  `type` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL,
  `question` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `options` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `answer` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `explanation` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` varchar(19) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cert_category_id` int unsigned DEFAULT NULL,
  `difficulty` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '中',
  `status` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'active',
  PRIMARY KEY (`id`),
  KEY `idx_questions_set` (`daily_set_id`,`set_index`),
  KEY `idx_q_category` (`cert_category_id`,`status`),
  CONSTRAINT `fk_questions_category` FOREIGN KEY (`cert_category_id`) REFERENCES `cert_categories` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_questions_set` FOREIGN KEY (`daily_set_id`) REFERENCES `daily_sets` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=253 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `questions`
--

LOCK TABLES `questions` WRITE;
/*!40000 ALTER TABLE `questions` DISABLE KEYS */;
INSERT INTO `questions` VALUES (93,NULL,0,'single','阿里云中用于隔离云上网络的逻辑边界是？','{\"A\": \"安全组\", \"B\": \"专有网络 VPC\", \"C\": \"负载均衡 SLB\", \"D\": \"云监控\"}','B','VPC 提供逻辑隔离的私有网络，可自定义网段、交换机与路由；安全组是实例级访问控制。','2026-11-07 00:01:50',2,'中','active'),(94,NULL,0,'single','ECS 实例的弹性公网 IP（EIP）解绑后，以下说法正确的是？','{\"A\": \"EIP 随实例一起释放\", \"B\": \"EIP 保留在账号下，可绑定到其它实例\", \"C\": \"EIP 自动转为私网地址\", \"D\": \"EIP 立即失效\"}','B','EIP 是独立资源，解绑后保留在账号中，可重新绑定到同地域其它实例。','2026-11-07 00:01:51',2,'中','active'),(95,NULL,0,'single','跨可用区部署 SLB 后端服务器的主要目的是？','{\"A\": \"降低带宽成本\", \"B\": \"提升可用性，单可用区故障时仍可服务\", \"C\": \"减少安全组规则\", \"D\": \"提高磁盘 IOPS\"}','B','多可用区部署可避免单可用区故障导致整体不可用，是典型的高可用设计。','2026-11-07 00:01:51',2,'中','active'),(96,NULL,0,'single','OSS 中用于控制对象访问权限的机制不包括？','{\"A\": \"Bucket ACL\", \"B\": \"RAM Policy\", \"C\": \"STS 临时凭证\", \"D\": \"安全组规则\"}','D','安全组作用于 ECS 网络层，不用于 OSS 的对象权限控制。','2026-11-07 00:01:51',2,'中','active'),(97,NULL,0,'multiple','以下哪些属于阿里云 RDS 提供的高可用能力？','{\"A\": \"主备实例自动切换\", \"B\": \"只读实例分流\", \"C\": \"跨地域备份\", \"D\": \"自动扩容磁盘\"}','A,B,C','RDS 支持主备高可用、只读实例与备份恢复；磁盘扩容需手动或按策略触发，不属于高可用切换能力。','2026-11-07 00:01:51',2,'中','active'),(98,NULL,0,'single','云监控中配置报警规则时，最适合用于触发扩容的指标是？','{\"A\": \"CPU 使用率持续高于 70%\", \"B\": \"磁盘剩余空间 90%\", \"C\": \"实例重启次数\", \"D\": \"安全组规则数量\"}','A','CPU/内存等负载指标是弹性伸缩的常用触发条件。','2026-11-07 00:01:51',2,'中','active'),(99,NULL,0,'judge','阿里云 SLB 支持四层（TCP/UDP）与七层（HTTP/HTTPS）负载均衡。','{\"A\": \"正确\", \"B\": \"错误\"}','A','SLB 提供四层与七层能力，七层支持基于域名/路径的转发。','2026-11-07 00:01:51',2,'中','active'),(100,NULL,0,'single','VPC 中交换机（vSwitch）的作用是？','{\"A\": \"划分可用区内的子网\", \"B\": \"提供公网 IP\", \"C\": \"做应用层路由\", \"D\": \"存储对象数据\"}','A','vSwitch 是 VPC 内的子网划分，且必须属于某一个可用区。','2026-11-07 00:01:51',2,'中','active'),(101,NULL,0,'single','为降低 OSS 公网流量成本，最合理的做法是？','{\"A\": \"全部使用公网访问\", \"B\": \"通过 CDN 回源并使用内网 Endpoint\", \"C\": \"关闭 Bucket 日志\", \"D\": \"把对象改为低频存储即可\"}','B','同地域内网 Endpoint 免公网流量费，CDN 可降低回源压力与跨地域流量。','2026-11-07 00:01:51',2,'中','active'),(102,NULL,0,'single','关于安全组与网络 ACL，说法正确的是？','{\"A\": \"安全组是有状态的，网络 ACL 是无状态的\", \"B\": \"两者都是有状态\", \"C\": \"网络 ACL 作用于实例网卡\", \"D\": \"安全组只能拒绝流量\"}','A','安全组有状态（返回流量自动放行），网络 ACL 无状态，需要分别配置进出方向。','2026-11-07 00:01:51',2,'中','active'),(103,NULL,0,'single','OSPF 中 Router-ID 的选举规则是？','{\"A\": \"最小接口 IP\", \"B\": \"最大 Loopback 地址，其次最大物理接口地址\", \"C\": \"随机生成\", \"D\": \"必须手工配置\"}','B','优先使用手工配置的 Router-ID；未配置时选最大的 Loopback 地址，再选最大物理接口地址。','2026-11-07 00:01:51',7,'中','active'),(104,NULL,0,'single','BGP 中用于避免路由环路的属性是？','{\"A\": \"AS_Path\", \"B\": \"Local_Preference\", \"C\": \"MED\", \"D\": \"Next_Hop\"}','A','AS_Path 记录经过的 AS 号，收到含本 AS 号的路由会被丢弃，从而防止环路。','2026-11-07 00:01:51',7,'中','active'),(105,NULL,0,'single','BGP 选路中，以下哪项优先级最高？','{\"A\": \"Local_Preference 较大\", \"B\": \"AS_Path 较短\", \"C\": \"MED 较小\", \"D\": \"Router-ID 较小\"}','A','华为设备 BGP 选路顺序中，Local_Preference 先于 AS_Path 比较。','2026-11-07 00:01:51',7,'中','active'),(106,NULL,0,'single','MPLS VPN 中用于区分不同客户路由的标识是？','{\"A\": \"RD\", \"B\": \"RT\", \"C\": \"Label\", \"D\": \"VLAN ID\"}','A','RD 用于在地址空间中区分不同 VPN 实例的前缀，RT 控制路由导入导出。','2026-11-07 00:01:51',7,'中','active'),(107,NULL,0,'multiple','VXLAN 相比传统 VLAN 的优势包括？','{\"A\": \"支持 16M 租户标识\", \"B\": \"可跨三层网络扩展二层域\", \"C\": \"完全不需要 Underlay 网络\", \"D\": \"支持 ECMP 负载分担\"}','A,B,D','VXLAN 仍依赖 Underlay IP 网络提供可达性，不能脱离底层网络。','2026-11-07 00:01:51',7,'中','active'),(108,NULL,0,'single','交换机上配置 Eth-Trunk 的主要目的是？','{\"A\": \"增加带宽并提供链路冗余\", \"B\": \"隔离广播域\", \"C\": \"实现路由汇总\", \"D\": \"做 NAT 转换\"}','A','链路聚合将多条物理链路捆绑为一条逻辑链路，提升带宽与可靠性。','2026-11-07 00:01:51',7,'中','active'),(109,NULL,0,'single','STP 中根桥的选举依据是？','{\"A\": \"最小 Bridge ID\", \"B\": \"最大端口速率\", \"C\": \"最小 MAC 地址\", \"D\": \"最大优先级\"}','A','Bridge ID = 优先级 + MAC，数值最小者成为根桥，默认优先级 32768。','2026-11-07 00:01:51',7,'中','active'),(110,NULL,0,'judge','OSPF 的 Stub 区域不允许 Type 5 LSA 进入。','{\"A\": \"正确\", \"B\": \"错误\"}','A','Stub 区域通过 Type 3 默认路由访问外部，禁止 Type 5 外部 LSA。','2026-11-07 00:01:51',7,'中','active'),(111,NULL,0,'single','网络割接前最重要的准备是？','{\"A\": \"准备好回滚方案与验证步骤\", \"B\": \"关闭所有日志\", \"C\": \"直接下发配置\", \"D\": \"先重启所有设备\"}','A','割接必须有明确的回滚方案、窗口与验证清单，控制变更风险。','2026-11-07 00:01:51',7,'中','active'),(112,NULL,0,'single','SD-WAN 相比传统专线的主要优势是？','{\"A\": \"基于应用策略选路，降低成本并提升灵活性\", \"B\": \"完全不需要物理链路\", \"C\": \"只能用于数据中心内部\", \"D\": \"不支持加密\"}','A','SD-WAN 通过集中控制器与应用识别实现智能选路，可混合使用多种链路。','2026-11-07 00:01:51',7,'中','active'),(113,NULL,0,'single','需要为跨多个可用区的高可用应用选择数据库，最合适的托管方案是？','{\"A\": \"单可用区 RDS\", \"B\": \"Aurora Multi-AZ\", \"C\": \"EC2 自建单机 MySQL\", \"D\": \"DynamoDB 本地部署\"}','B','Aurora Multi-AZ 提供跨 AZ 的存储副本与故障转移，是高可用托管数据库的首选。','2026-11-07 00:01:51',19,'中','active'),(114,NULL,0,'single','S3 中用于防止对象被意外删除的机制是？','{\"A\": \"版本控制 + MFA Delete\", \"B\": \"存储桶 ACL\", \"C\": \"生命周期规则\", \"D\": \"跨区域复制\"}','A','版本控制保留历史版本，MFA Delete 为删除操作增加二次认证。','2026-11-07 00:01:51',19,'中','active'),(115,NULL,0,'single','以下哪种方案最适合将静态网站托管成本降到最低？','{\"A\": \"EC2 + EBS\", \"B\": \"S3 静态网站托管 + CloudFront\", \"C\": \"ECS Fargate\", \"D\": \"Lambda 每次渲染\"}','B','S3 + CloudFront 无需服务器，按存储与请求计费，适合静态内容。','2026-11-07 00:01:51',19,'中','active'),(116,NULL,0,'single','VPC 中私有子网访问互联网的正确做法是？','{\"A\": \"给实例绑定公网 IP\", \"B\": \"通过 NAT Gateway 出网\", \"C\": \"配置 Internet Gateway 直连\", \"D\": \"使用 VPC Peering\"}','B','私有子网没有公网路由，需通过 NAT Gateway 访问互联网，入站不可达。','2026-11-07 00:01:51',19,'中','active'),(117,NULL,0,'multiple','IAM 策略中显式 Deny 的特点包括？','{\"A\": \"优先级高于 Allow\", \"B\": \"可覆盖资源策略的允许\", \"C\": \"只对根账号生效\", \"D\": \"需要与 Allow 同时存在才生效\"}','A,B','显式 Deny 在策略评估中始终优先，可覆盖身份策略与资源策略的 Allow。','2026-11-07 00:01:51',19,'中','active'),(118,NULL,0,'single','ELB 健康检查失败时，默认行为是？','{\"A\": \"继续转发流量\", \"B\": \"将实例从目标组摘除，不再转发\", \"C\": \"自动重启实例\", \"D\": \"降低实例权重到 0 但保持连接\"}','B','不健康目标会被摘除，恢复健康后重新加入。','2026-11-07 00:01:51',19,'中','active'),(119,NULL,0,'judge','AWS Well-Architected Framework 包含安全性、可靠性、性能效率、成本优化、卓越运营和可持续性六大支柱。','{\"A\": \"正确\", \"B\": \"错误\"}','A','六大支柱即安全、可靠、性能、成本、运营与可持续性。','2026-11-07 00:01:51',19,'中','active'),(120,NULL,0,'single','需要解耦订单服务与库存服务，最合适的托管消息服务是？','{\"A\": \"SQS\", \"B\": \"CloudFront\", \"C\": \"Route 53\", \"D\": \"EBS\"}','A','SQS 提供托管队列，实现异步解耦与削峰填谷。','2026-11-07 00:01:51',19,'中','active'),(121,NULL,0,'single','跨区域灾备中，RTO 最小时通常选择？','{\"A\": \"备份恢复到新区域\", \"B\": \"热备（Active-Active）多区域部署\", \"C\": \"冷备\", \"D\": \"仅做快照\"}','B','双活多区域可做到分钟级甚至近实时切换，RTO 最小，但成本最高。','2026-11-07 00:01:51',19,'中','active'),(122,NULL,0,'single','Lambda 函数访问 VPC 内 RDS 时，需要配置？','{\"A\": \"VPC 子网与安全组\", \"B\": \"仅 IAM 角色\", \"C\": \"公网网关\", \"D\": \"NAT 实例即可\"}','A','Lambda 需加入目标 VPC 的子网并配置安全组，同时具备相应 IAM 权限。','2026-11-07 00:01:51',19,'中','active'),(123,NULL,0,'single','IP 地址 192.168.10.130/26 所在子网的网络地址是？','{\"A\": \"192.168.10.0\", \"B\": \"192.168.10.64\", \"C\": \"192.168.10.128\", \"D\": \"192.168.10.192\"}','C','/26 掩码为 255.255.255.192，块大小 64，128 是 130 所在子网的网络地址。','2026-11-07 00:01:51',26,'中','active'),(124,NULL,0,'single','VLAN 的主要作用是？','{\"A\": \"扩大广播域\", \"B\": \"划分广播域\", \"C\": \"加密数据\", \"D\": \"分配公网 IP\"}','B','VLAN 在二层划分广播域，减少广播风暴并提升安全隔离。','2026-11-07 00:01:52',26,'中','active'),(125,NULL,0,'single','两台交换机之间需要承载多个 VLAN，应配置？','{\"A\": \"Access 口\", \"B\": \"Trunk 口\", \"C\": \"Loopback 口\", \"D\": \"三层路由口\"}','B','Trunk 通过 802.1Q 标签在一条链路上承载多个 VLAN。','2026-11-07 00:01:52',26,'中','active'),(126,NULL,0,'single','OSPF 中 DR/BDR 选举发生在？','{\"A\": \"任意两台路由器之间\", \"B\": \"广播或 NBMA 网络中\", \"C\": \"点到点网络\", \"D\": \"所有网络类型\"}','B','点到点网络不需要 DR/BDR，广播与 NBMA 网络才进行选举。','2026-11-07 00:01:52',26,'中','active'),(127,NULL,0,'single','标准 ACL 的匹配依据是？','{\"A\": \"源 IP 地址\", \"B\": \"目的 IP 地址\", \"C\": \"源端口\", \"D\": \"协议类型\"}','A','标准 ACL（1-99）只能匹配源 IP；扩展 ACL 可匹配源/目的 IP、端口与协议。','2026-11-07 00:01:52',26,'中','active'),(128,NULL,0,'single','默认路由在路由表中的表示是？','{\"A\": \"0.0.0.0/0\", \"B\": \"255.255.255.255/32\", \"C\": \"127.0.0.0/8\", \"D\": \"224.0.0.0/4\"}','A','0.0.0.0/0 匹配所有目的地址，作为最后兜底路由。','2026-11-07 00:01:52',26,'中','active'),(129,NULL,0,'judge','交换机收到未知单播帧时会泛洪到同一 VLAN 的其它端口。','{\"A\": \"正确\", \"B\": \"错误\"}','A','MAC 地址表中没有对应条目时，交换机会在 VLAN 内泛洪。','2026-11-07 00:01:52',26,'中','active'),(130,NULL,0,'single','SSH 相比 Telnet 的核心优势是？','{\"A\": \"速度更快\", \"B\": \"传输加密与身份认证\", \"C\": \"不需要 IP 地址\", \"D\": \"支持更多命令\"}','B','SSH 对会话加密并提供设备认证，Telnet 明文传输不安全。','2026-11-07 00:01:52',26,'中','active'),(131,NULL,0,'single','查看 Cisco 设备接口 IP 与状态的命令是？','{\"A\": \"show ip interface brief\", \"B\": \"show running-config\", \"C\": \"show version\", \"D\": \"show mac address-table\"}','A','show ip interface brief 以一屏表格显示接口、IP、状态与协议。','2026-11-07 00:01:52',26,'中','active'),(132,NULL,0,'single','生成树协议中，非根桥到根桥开销最小的端口称为？','{\"A\": \"根端口\", \"B\": \"指定端口\", \"C\": \"阻塞端口\", \"D\": \"边缘端口\"}','A','每台非根桥选举一个根端口，到根桥路径开销最小。','2026-11-07 00:01:52',26,'中','active'),(233,NULL,1,'single','运维同学把一段应用启动脚本写入 ECS 实例的自定义数据（User-Data），实例首次创建后脚本正常执行。后来他修改了脚本内容并重启实例，发现新脚本没有运行。最可能的原因是？','{\"A\": \"自定义数据每次实例启动都会执行，脚本中缺少幂等判断导致被跳过\", \"B\": \"自定义数据仅在创建实例后 10 分钟内有效，超时后脚本自动失效\", \"C\": \"自定义数据只在实例**首次启动初始化**时执行一次，普通重启不会重新执行，需重新初始化系统盘或更换系统盘后才会再次执行\", \"D\": \"自定义数据必须同时写入 `/etc/rc.local` 才会被执行，否则只是落盘不运行\"}','C','- **考点**：实例自定义数据（User-Data）的执行时机。阿里云 ECS 的自定义数据由 cloud-init 在实例**第一次启动**时执行，且**只执行一次**；后续 `RebootInstance` 重启、`StartInstance` 开机都不会再次执行。运维侧常见的\"改了脚本不生效\"，根因就在这里。\n- **易错点**：\n  - ① 选 A：不是幂等性问题，而是根本没被触发；如果想每次启动都执行，应把逻辑放进 systemd 服务或 rc.local，而不是 User-Data。\n  - ② 选 B：自定义数据没有\"10 分钟有效期\"这一说；限制是**单条自定义数据 ≤ 32 KB**（Base64 编码前），超限会导致创建实例时下发失败。\n  - ③ 选 D：脚本本身就会被 cloud-init 执行，写入 rc.local 是\"另一种每次开机执行\"的手段，不是 User-Data 生效的前提。\n- **延伸**：想重新触发 User-Data，可采用\"**重新初始化系统盘**（保留数据盘）\"或\"**更换系统盘**\"两类操作，二者都会重置系统盘并把实例恢复到初始化状态；生产环境执行前务必确认系统盘无未备份数据。另外，User-Data 中**不要放明文 AK/密码**——它可通过实例元数据被读取，规范做法是用实例 RAM 角色 + STS 临时凭证。','2026-11-07 17:02:26',2,'中','active'),(234,NULL,2,'single','安全团队在渗透测试中指出：某台 ECS 上的 Web 应用存在 SSRF 漏洞，攻击者可能通过它访问实例元数据服务，从而窃取绑定在实例上的临时凭证。为了从实例侧收敛这个风险，最直接有效的配置是？','{\"A\": \"将实例元数据访问模式设置为**加固模式**，实例内应用需先获取 Token 再访问 `100.100.100.200`\", \"B\": \"关闭元数据服务，因为元数据服务关闭后实例将无法访问公网\", \"C\": \"加固模式下元数据地址变更为 `169.254.169.254`，攻击者无法猜测\", \"D\": \"加固模式只对包年包月实例生效，按量付费实例仍需依赖应用层修复\"}','A','- **考点**：ECS 元数据服务的两种访问模式。**普通模式**下，实例内任意进程直接 `curl http://100.100.100.200/latest/meta-data/` 即可读取实例 ID、镜像、临时凭证等信息，SSRF 一旦打通就是\"凭证泄露\"；**加固模式（安全加固）**要求先调用 Token 接口拿到有时效的 Token，再携带 Token 访问元数据，无 Token 的裸请求一律拒绝，可显著抬高 SSRF 的利用门槛。\n- **易错点**：\n  - ① 选 B：元数据服务是**内网链路**，与实例访问公网无关；关闭公网能力应该靠\"不分配公网 IP / 不绑 EIP / NAT 出网\"，而不是关元数据。\n  - ② 选 C：`100.100.100.200` 是阿里云元数据服务的固定地址，加固模式并不换地址；`169.254.169.254` 是其他云厂商的地址，属于典型\"串台\"干扰项。\n  - ③ 选 D：访问模式是实例级配置，与付费类型无关。\n- **延伸**：加固模式的 Token 有有效期（可设置，最长 21600 秒），应用需实现\"过期前刷新\"；此外可叠加 **实例 RAM 角色的最小权限**（只授业务真正需要的 API）与**元数据访问来源限制**，形成\"拿不到 / 拿到也没用\"的双层防护。SSRF 场景还需在应用层做地址白名单，云上配置不能替代代码修复。','2026-11-07 17:02:26',2,'中','active'),(235,NULL,3,'single','某业务需要\"一机双网\"：一台 ECS 同时接入两个不同子网，分别承载管理流量与业务流量，并希望后续可在线调整。下列关于弹性网卡（ENI）的说法，正确的是？','{\"A\": \"辅助网卡可以跨可用区挂载，只要与实例属于同一 VPC\", \"B\": \"主网卡可以从实例卸载后重新绑定到另一台实例，用于快速迁移\", \"C\": \"挂载辅助网卡后 VPC 会自动下发策略路由，实例内无需任何配置\", \"D\": \"辅助网卡须与实例同 VPC 同可用区，**主网卡不可卸载**，多网卡场景需在系统内自行配置策略路由/多路由表\"}','D','- **考点**：弹性网卡的生命周期约束与多网卡路由配置。ENI 是**可用区级**资源，只能挂载到同可用区、同 VPC 的实例上；**主网卡随实例创建，不可卸载**，辅助网卡支持热插拔（部分实例规格/镜像需重启生效）。多网卡属于\"多宿主\"场景，操作系统默认只有一张默认路由，必须自行做策略路由（源地址选路），否则业务流量仍然只从主网卡出去。\n- **易错点**：\n  - ① 选 A：跨可用区挂载不成立，这是 ENI 与 EIP 最容易混淆的点——EIP 是地域级、可跨可用区绑定，ENI 是可用区级。\n  - ② 选 B：主网卡不可卸载；\"迁移\"应通过**自定义镜像 + 更换系统盘**或**实例迁移**实现，不是搬网卡。\n  - ③ 选 C：云平台只负责二层/三层可达与安全组绑定，**不代做操作系统路由**；不配策略路由的典型现象是\"eth1 有 IP 但流量仍走 eth0\"。\n- **延伸**：给辅助网卡配默认网关是常见坑——Linux 下多个默认路由会按 metric 竞争，容易导致回包从错误网卡发出而被丢弃。正确做法是**按源地址策略路由**（`ip rule` + 独立路由表），并确保辅助网卡所在子网的安全组/网络 ACL 已放通。容器场景中，Terway 正是基于 ENI 做 Pod 网络，网卡数量上限直接决定单节点 Pod 密度。','2026-11-07 17:02:26',2,'中','active'),(236,NULL,4,'single','安全合规要求：某个子网内的所有 ECS 一律禁止对公网开放 22 端口，但运维仍需通过堡垒机访问其中的个别实例。下列方案最合理的是？','{\"A\": \"在子网关联的网络 ACL 中添加\\\"拒绝 22 入方向\\\"的规则，再为个别实例单独添加允许规则\", \"B\": \"通过**安全组**只对堡垒机所在网段放通 22，其他源地址默认拒绝（安全组无拒绝规则，默认即拒绝）\", \"C\": \"把网络 ACL 的拒绝规则号设为 100（数值越大优先级越高），即可实现精细控制\", \"D\": \"安全组不支持按源 IP 授权，必须依赖网络 ACL 才能实现\"}','B','- **考点**：安全组与网络 ACL 的能力边界。**安全组**作用于实例/弹性网卡，**有状态**（放通入方向后返回流量自动放行），规则**只有允许（Accept）**，未匹配即拒绝，规则优先级 1–100 且数值越小越优先；**网络 ACL** 作用于交换机（子网），**无状态**（入、出方向要分别放通），同时支持**允许与拒绝**，按规则号从小到大匹配。\n- **易错点**：\n  - ① 选 A：ACL 是子网级的，一旦拒绝 22，子网内**所有**实例都受影响，无法再对个别实例\"开小口\"；而且无状态，即使放通入方向，回程流量也要单独放通。\n  - ② 选 C：ACL 规则号**小的优先**，把拒绝规则放到 100 反而可能被前面的允许规则命中；且 ACL 粒度仍然是子网，解决不了\"个别实例\"。\n  - ③ 选 D：安全组恰恰是按源 IP/网段/安全组 ID 授权的，这是它相对 ACL 的核心优势。\n- **延伸**：分层思路要记牢——**网络 ACL 做子网级粗粒度兜底（如整段封禁高危端口、封禁恶意 IP 段），安全组做实例级精细授权**。两者同时存在时流量要**依次通过**：入方向先过 ACL 再过安全组，出方向先过安全组再过 ACL，任一环节拒绝即不通。排障时\"安全组已放通仍不通\"十有八九是 ACL 或路由问题。','2026-11-07 17:02:26',2,'中','active'),(237,NULL,5,'single','某公司有 20 个 EIP 分别绑定在不同业务实例上，每个 EIP 单独购买 100 Mbps 固定带宽，但各业务峰值时段错开，整体带宽利用率不足 30%。财务要求降本，同时不能降低任一时刻的可用带宽。下列方案与描述正确的是？','{\"A\": \"将这些 EIP 加入**共享带宽**实例：加入后 EIP 自身带宽峰值失效，出入带宽由共享带宽统一分配，费用按共享带宽计费\", \"B\": \"加入共享带宽后每个 EIP 仍保留原有 100 Mbps 独享峰值，共享带宽仅作为超额部分的补充\", \"C\": \"共享带宽实例只能绑定同一可用区内的 EIP，跨可用区 EIP 无法加入\", \"D\": \"增强型 95 计费按天剔除最高 5% 的采样点，因此特别适合每日剧烈波动的业务\"}','A','- **考点**：共享带宽的复用模型与计费方式。共享带宽是**地域级**的带宽复用资源池，多个 EIP 加入后**不再各自计费、也不再各自保留独立峰值**，而是共享池子的总带宽；计费支持\"按带宽\"和\"按增强型 95\"两种。业务峰值错开时，池化能显著降低总成本。\n- **易错点**：\n  - ① 选 B：加入后原独立带宽峰值失效，这正是共享带宽能省钱的原因；若想保留独享峰值，就不应加入共享带宽。\n  - ② 选 C：共享带宽是**地域级**资源，同地域不同可用区的 EIP 都可以加入；\"可用区级\"是 ENI、交换机、ECS 的粒度。\n  - ③ 选 D：增强型 95 计费的采样粒度是**每 5 分钟一个点**，**按月**统计并剔除最高的 5% 采样点后取峰值计费，不是\"按天\"；它适合**长期波动但尖峰偶发**的业务，若每天都长时间处于高位则不如固定带宽划算。\n- **延伸**：共享带宽的隐性约束是\"**总带宽被抢占**\"——池子被打满时，所有 EIP 一起受影响，因此关键业务 EIP 建议单独保留带宽或使用\"共享带宽 + 业务限速\"。跨地域统一出口则要上 **GA（全球加速）或 CEN 带宽包**，不要与共享带宽混淆。','2026-11-07 17:02:26',2,'中','active'),(238,NULL,6,'single','三个 VPC 的网段分别为 A `10.0.0.0/16`、B `10.1.0.0/16`、C `10.2.0.0/16`。管理员已创建 A↔B、B↔C 两条对等连接（Peering），并在双方路由表中添加了对应路由。此时 A 内实例仍然 ping 不通 C 内实例，最可能的原因是？','{\"A\": \"三个 VPC 网段存在重叠，对等连接无法生效\", \"B\": \"对等连接只支持同地域，跨地域必须改用 VPN 网关\", \"C\": \"对等连接**不传递路由**，A 与 C 之间必须单独创建对等连接，并在双方路由表中添加指向对方网段的路由\", \"D\": \"只需在 A、C 的路由表中互相添加指向对方网段的路由即可打通，无需新建连接\"}','C','- **考点**：VPC 对等连接的\"非传递性\"。对等连接是**两两之间**的点对点连接，只打通直连的两个 VPC；A-B、B-C 存在**不代表** A-C 可达。跨账号、跨地域都支持（跨地域需注意带宽与计费），但**网段不能重叠**。\n- **易错点**：\n  - ① 选 A：本题网段互不重叠，前提不成立；网段重叠确实是对等连接的硬限制，也是选型时要先核对的第一项。\n  - ② 选 B：对等连接支持跨地域，只是跨地域流量按方向计费；\"只能同地域\"是错误记忆。\n  - ③ 选 D：没有对等连接这个\"通道\"，路由表里写再多静态路由也不会通——路由只是指路，链路本身不存在。典型现象是路由条目处于**冲突/无效**状态。\n- **延伸**：VPC 数量一多，对等连接的复杂度是 O(n²)。多 VPC 全互通应改用**云企业网 CEN + 转发路由器 TR**，它支持路由自动学习、路由表隔离、带宽包统购；网段重叠场景则只能用 **PrivateLink（私网连接）** 做服务级暴露，而不是打通整网。这是\"组网选型\"高频考点。','2026-11-07 17:02:26',2,'中','active'),(239,NULL,7,'single','一款手游使用 CLB 的 **TCP 监听**承载长连接，运维开启了会话保持。上线后发现部分后端服务器连接数暴涨、部分几乎空闲。下列解释与判断正确的是？','{\"A\": \"四层会话保持基于 Cookie 植入，需要后端应用配合写入 Cookie 才能生效\", \"B\": \"四层会话保持超时时间最长可设为 24 小时，因此长连接场景不会出现重分配\", \"C\": \"开启会话保持后 CLB 将不再对后端服务器执行健康检查\", \"D\": \"四层会话保持基于**源 IP**，NAT 后大量客户端共享同一出口 IP，会被固定到同一后端，造成负载倾斜\"}','D','- **考点**：四层与七层会话保持的实现差异。**TCP/UDP 监听**没有 HTTP 语义，只能按**源 IP**（配合调度算法）做会话保持，超时时间范围 **10–3600 秒**；**HTTP/HTTPS 监听**才支持 **Cookie 植入**（会话保持超时 1–86400 秒），由 CLB 在后端响应中写入 Cookie 并据此粘滞。\n- **易错点**：\n  - ① 选 A：四层无 HTTP 头，谈不上 Cookie 植入；Cookie 方案属于七层。\n  - ② 选 B：四层会话保持上限是 3600 秒（1 小时），不是 24 小时。\n  - ③ 选 C：会话保持与健康检查是相互独立的能力，健康检查始终生效，且后端异常时连接会被重新调度。\n- **延伸**：源 IP 会话保持的\"翻车\"场景很典型——**办公网/运营商大 NAT、容器出口 IP 收敛、四层代理套娃**，都会把成百上千客户端压到一台后端。更稳的做法是：长连接业务用**一致性哈希（源 IP 哈希）**配合较大后端池，或在应用层用业务会话 ID 做路由；同时避免在 CLB 前面再叠一层 SNAT。另外 CLB 支持**连接优雅中断**，缩容时先摘除后端再等待存量连接自然结束，可减少掉线。','2026-11-07 17:02:26',2,'中','active'),(240,NULL,8,'single','大促前，运营更新了首页的一批静态资源（JS/CSS/图片），希望全网用户尽快拿到新版本，同时不希望瞬间大量请求打回源站。下列操作顺序最合适的是？','{\"A\": \"只做预热即可，预热会自动覆盖边缘节点上的旧缓存\", \"B\": \"先**刷新**对应 URL 使边缘节点旧缓存失效，再对这批资源做**预热**，把新内容提前分发到节点\", \"C\": \"只做刷新即可，刷新后 CDN 会自动预热，无需额外操作\", \"D\": \"把该域名的缓存过期时间设为 0，全部请求回源以保证最新\"}','B','- **考点**：CDN 刷新与预热的语义差异。**刷新（Refresh/Purge）**是把边缘节点上已有的缓存标记为失效，下一次请求回源取新内容；**预热（Preload）**是主动把源站内容**预先拉取并缓存**到节点。二者组合才能既\"快生效\"又\"不回源尖峰\"。\n- **易错点**：\n  - ① 选 A：预热不覆盖已缓存的旧内容——节点上已有未过期副本时，预热通常不会强行替换，必须先刷新。这是本题最大的坑。\n  - ② 选 C：刷新后节点处于\"无缓存\"状态，第一个请求仍然回源，并不等于预热。\n  - ③ 选 D：过期时间 0 等于关闭缓存，所有请求全部回源，源站很可能被打挂，与题干目标相反。\n- **延伸**：刷新/预热都是**有配额**的操作（URL 刷新、目录刷新、预热的每日条数各不相同，超限需提工单），大促前要提前规划并分批执行。更根本的方案是**资源指纹化**（文件名带 hash）+ 长缓存 + HTML 短缓存，靠\"换 URL\"而不是\"刷缓存\"来发布，这是大型站点的标准姿势。','2026-11-07 17:02:26',2,'中','active'),(241,NULL,9,'single','某图片站点接入 CDN 后，命中率长期只有 20% 左右。抓包发现图片 URL 形如 `https://img.example.com/a.jpg?sign=xxxx&t=1720000000`，其中 `sign` 与 `t` 每次请求都变化。在不影响鉴权的前提下，提升命中率最有效的手段是？','{\"A\": \"关闭该域名的缓存，全部请求回源，避免命中率指标失真\", \"B\": \"把缓存过期时间缩短到 60 秒，减少缓存碎片\", \"C\": \"配置\\\"**忽略参数**\\\"（或仅保留必要参数）作为缓存 Key 的组成规则，使鉴权参数不同的同一资源共享同一缓存对象\", \"D\": \"开启 Range 回源，让节点按分片缓存\"}','C','- **考点**：CDN 缓存 Key 的构成。默认缓存 Key 通常是 `域名 + 路径 + 全部查询参数`，参数一变就是\"新对象\"，于是同一张图片被缓存成 N 份且都不命中。阿里云 CDN 支持**忽略参数**（全部忽略 / 保留指定参数 / 删除指定参数），把与内容无关的鉴权、时间戳参数从 Key 中剔除。\n- **易错点**：\n  - ① 选 A：关缓存是最贵的\"解法\"，源站带宽与延迟都会爆。\n  - ② 选 B：缩短 TTL 只会让缓存更快失效，命中率更低。\n  - ③ 选 D：Range 回源解决的是大文件分片下载与断点续传，与缓存 Key 无关。\n- **延伸**：开启\"忽略参数\"要评估**内容串号风险**——如果参数真的决定返回内容（如 `?w=200` 做图片缩放），忽略后会出现\"小图变大图\"。正确做法是**只忽略 `sign`、`t` 这类与内容无关的参数**。与之配套的还有**缓存过期时间按目录/文件类型分级**、**回源 SNI/HOST 配置**，三者共同决定命中率与正确性。','2026-11-07 17:02:26',2,'中','active'),(242,NULL,10,'single','某 Bucket 设置为公共读，管理员配置了 Referer 白名单防盗链，只允许 `*.example.com`。配置完成后，用户在浏览器地址栏**直接输入图片 URL** 访问，返回 403。最可能的原因与修复方式是？','{\"A\": \"未勾选\\\"**允许空 Referer**\\\"：地址栏直接访问、以及部分客户端请求不携带 Referer 头，会被防盗链规则拒绝；勾选后放行空 Referer\", \"B\": \"防盗链配置需要 10 分钟生效，等待后自动恢复\", \"C\": \"Referer 白名单不支持通配符，`*.example.com` 写法本身非法\", \"D\": \"必须为 Bucket 绑定自定义域名，使用默认域名时防盗链不生效\"}','A','- **考点**：Referer 防盗链的匹配规则与\"空 Referer\"选项。OSS 防盗链支持白名单/黑名单，白名单支持 `*` 通配（如 `*.example.com`、`http://*.example.com`）。关键开关是**是否允许空 Referer**：不允许时，任何不带 Referer 头的请求（地址栏直接访问、`curl`、部分 App 内置浏览器、隐私模式）都会被拒。\n- **易错点**：\n  - ① 选 B：防盗链配置基本即时生效，不存在固定 10 分钟延迟；这类\"等一会就好了\"的选项通常是干扰项。\n  - ② 选 C：白名单支持通配符，写法合法。\n  - ③ 选 D：防盗链对默认域名和自定义域名都生效。\n- **延伸**：Referer 是**浏览器行为**，可被伪造（改包、服务端请求），因此它只是\"防君子\"的降本手段，**不能当安全边界**。真正的保护是**私有 Bucket + 签名 URL（带过期时间）**，必要时再叠加 **Bucket Policy 限制源 IP / VPC**、**CDN 的 URL 鉴权（A/B/C 型）**。另外，CDN 回源 OSS 时若开启了\"过滤参数\"，要注意签名参数可能被过滤掉导致回源 403。','2026-11-07 17:02:26',2,'中','active'),(243,NULL,11,'single','前端使用浏览器直传 OSS（`PUT` + 签名），本地调试一直报跨域错误。管理员已在 Bucket 上配置了 CORS 规则，但仍然失败。该域名实际解析到 CDN 加速域名。最可能的原因是？','{\"A\": \"OSS 的 CORS 配置需要等待 10 分钟缓存刷新后才生效\", \"B\": \"必须为 Bucket 绑定自定义域名后 CORS 才会生效\", \"C\": \"前端直传必须使用 HTTPS，HTTP 下浏览器不发送预检请求\", \"D\": \"请求经 CDN 转发时，**CDN 侧未配置跨域响应头**，预检（OPTIONS）响应缺少 `Access-Control-Allow-Origin` 等头部，被浏览器拦截\"}','D','- **考点**：浏览器跨域直传的完整链路。CORS 是**浏览器**执行的同源策略放宽机制：非简单请求会先发 `OPTIONS` 预检，服务端必须在响应中返回 `Access-Control-Allow-Origin`、`Access-Control-Allow-Methods`、`Access-Control-Allow-Headers`（以及需要暴露的 `Access-Control-Expose-Headers`，如 `ETag`）。经过 CDN 后，**CDN 节点是浏览器看到的\"服务端\"**，因此 CDN 也必须配置跨域头；只配 OSS 不够。\n- **易错点**：\n  - ① 选 A：CORS 规则保存后很快生效，不存在 10 分钟缓存。\n  - ② 选 B：CORS 与是否绑定自定义域名无关，默认域名同样支持。\n  - ③ 选 C：HTTPS 与是否发送预检无关；预检由请求方法、头部、Content-Type 决定（如 `PUT`、自定义头 `x-oss-*` 必然触发预检）。\n- **延伸**：直传场景还有两个高频坑——**签名中的 `Content-Type` 必须与请求头完全一致**，否则 403 `SignatureDoesNotMatch`；**POST 表单直传的 Policy 过期时间**设置过短会让大文件上传中途失败。另外 CDN 开启\"过滤参数\"时要确认 `x-oss-*` 头部未被丢弃，否则签名校验失败。','2026-11-07 17:02:26',2,'中','active'),(244,NULL,12,'single','管理员为 RAM 用户 `ops01` 授予了 `AliyunOSSFullAccess`，随后又在 Bucket Policy 中针对该用户写了 `Effect: Deny` 的 `oss:DeleteObject`。结果 `ops01` 删除对象时报无权限。下列解释正确的是？','{\"A\": \"Bucket Policy 只对匿名用户生效，对 RAM 用户不起作用\", \"B\": \"权限评估中**显式 Deny 优先于任何 Allow**，RAM Policy 与 Bucket Policy 叠加后以\\\"拒绝优先\\\"为准\", \"C\": \"RAM Policy 的优先级高于 Bucket Policy，因此应当是 Bucket Policy 配置写错了\", \"D\": \"需要重启 Bucket 使 Policy 生效\"}','B','- **考点**：阿里云 RAM 的权限评估逻辑。一个请求会同时经过**身份策略（RAM Policy，挂在用户/用户组/角色上）**与**资源策略（Bucket Policy 等）**评估，最终结果是**所有 Allow 的并集**，但只要出现**任意一条显式 Deny**，结果即为拒绝——这就是\"显式拒绝优先\"。\n- **易错点**：\n  - ① 选 A：Bucket Policy 既支持匿名授权，也支持同账号 RAM 用户、跨账号账号/角色的授权与拒绝。\n  - ② 选 C：二者不是\"谁优先级高\"的关系，而是**同一套评估引擎的不同输入**；Deny 无条件胜出。\n  - ③ 选 D：Policy 保存后即生效，无需重启；若感觉\"没生效\"，多半是 Policy 语法或 Principal 写法有误。\n- **延伸**：这个机制常被用作\"**兜底护栏**\"——在 Bucket Policy 里对 `oss:DeleteBucket`、`oss:PutBucketAcl` 等高风险操作统一 Deny，即使有人被误授了 FullAccess 也删不掉桶。同理，**RAM 权限边界（Permission Boundary）**与**资源目录的管控策略（Control Policy）**也是\"限制上限\"的工具，区别在于作用对象：前者限制单个 RAM 主体，后者限制整个成员账号。','2026-11-07 17:02:26',2,'中','active'),(245,NULL,13,'single','某订单系统把订单状态放在 Redis 中，开启 AOF 持久化并使用默认的 `appendfsync everysec`。一次宿主机故障后，业务发现丢失了约 1 秒内的订单状态变更。下列判断正确的是？','{\"A\": \"把 `appendfsync` 改为 `always` 即可做到零丢失，且对性能没有影响\", \"B\": \"开启 AOF 后不能再同时开启 RDB，否则两种文件会互相覆盖\", \"C\": \"`everysec` 的设计就是\\\"每秒刷盘一次\\\"，最多可能丢失约 1 秒写入；Redis 不宜作为唯一数据源，关键状态需业务侧（数据库/消息队列）兜底\", \"D\": \"AOF 重写期间会阻塞所有读写请求，生产环境应关闭自动重写\"}','C','- **考点**：Redis AOF 的三种刷盘策略与持久化边界。`appendfsync always` 每条命令都 fsync，最安全但吞吐骤降；`everysec` 每秒 fsync 一次，**故障时最多丢约 1 秒数据**，是性能与安全的折中；`no` 交给操作系统决定，丢失窗口不可控。\n- **易错点**：\n  - ① 选 A：`always` 能显著缩小窗口但仍有极端情况（如 fsync 前后宕机、磁盘故障），而且**性能代价很大**，\"零丢失 + 无影响\"是不可能同时成立的。\n  - ② 选 B：Redis 支持**混合持久化**（RDB 全量 + AOF 增量），4.0 之后是推荐配置；两者是互补而非互斥。\n  - ③ 选 D：AOF 重写由**子进程** fork 完成（copy-on-write），主进程继续服务，只在 fork 瞬间有短暂停顿；关闭自动重写反而会让 AOF 文件无限膨胀、恢复变慢。\n- **延伸**：Redis 的定位要清楚——它是**缓存/加速层**，不是账本。真正需要\"不丢\"的数据应落库并保证幂等，或用**阿里云 Tair/Redis 的持久化 + 多可用区容灾**做工程兜底。此外要监控 `aof_rewrite_in_progress`、`rdb_changes_since_last_save`，以及 fork 时的**内存页表开销**（大实例 fork 可能触发 OOM）。','2026-11-07 17:02:26',2,'中','active'),(246,NULL,14,'single','某电商在 RDS MySQL 上配置了\"主实例 + 2 个只读实例 + 数据库代理（读写分离）\"。上线后出现\"用户下单成功，立即查询订单详情却提示不存在\"的投诉。下列分析与处理最合理的是？','{\"A\": \"只读实例为**异步复制**存在延迟，刚写入的数据可能还没同步；可通过数据库代理的**会话一致性**（保证读到自己写）或将这类强一致查询强制走主库来解决\", \"B\": \"只读实例未开启 binlog，导致数据无法同步，应补开 binlog\", \"C\": \"提高只读实例规格即可消除延迟，因为延迟由 CPU 性能决定\", \"D\": \"主实例未开启高可用版，读写分离本身不可用\"}','A','- **考点**：读写分离的数据一致性模型。RDS 只读实例通过 binlog **异步**复制，天然存在延迟（大事务、DDL、批量导入时会放大到分钟级）。数据库代理默认把读请求按权重分发到只读实例，写请求走主库；开启**会话一致性**后可保证\"同一会话内读到自己刚写的数据\"，但仍是\"读己之写\"而非全局强一致。\n- **易错点**：\n  - ① 选 B：只读实例的数据同步依赖主实例的 binlog，只读实例自身**不需要**再开 binlog（除非它还要做级联）；把\"没开 binlog\"当原因是方向性错误。\n  - ② 选 C：延迟的根因是**复制链路与主库写入压力**，堆只读实例规格解决不了\"数据还没到\"的问题。\n  - ③ 选 D：读写分离与高可用版是两件独立的事。\n- **延伸**：工程上的常规做法是**按业务分级**——\"下单后立即回显\"这类强一致读走主库（代理可配 `/*FORCE_MASTER*/` 提示或单独数据源），\"列表页、报表\"走只读。同时必须监控 **`Seconds_Behind_Master`/复制延迟**，并对大事务做拆分。若延迟长期不可接受，应考虑 **PolarDB（共享存储，只读节点无复制延迟）**。','2026-11-07 17:02:26',2,'中','active'),(247,NULL,15,'single','某客户有一张亿级大表需要做实时报表分析，现有 RDS MySQL 主库压力已经很高。要求：新增只读节点后**不能有主从复制延迟**，且不希望为只读节点额外复制一份完整数据。最合适的方案是？','{\"A\": \"为 RDS MySQL 主实例新增只读实例，异步复制可满足毫秒级一致性要求\", \"B\": \"使用 Redis 只读副本承接报表查询，缓解主库压力\", \"C\": \"为 RDS 开启数据库代理并设置读一致性，即可消除复制延迟\", \"D\": \"使用 **PolarDB 集群版**新增只读节点：计算存储分离、多个节点**共享同一份分布式存储**，只读节点无需复制数据，延迟在毫秒级\"}','D','- **考点**：PolarDB 的存储计算分离架构。PolarDB 的多个计算节点共享同一份基于分布式存储的数据库数据，只读节点**不复制数据**，通过读取共享存储 + Redo 日志回放保持一致性，因此\"加节点\"是**秒级到分钟级**操作，且没有传统主从的\"数据量越大延迟越难控\"的问题；写节点把 Redo 写入共享存储，只读节点回放，延迟通常在毫秒级。\n- **易错点**：\n  - ① 选 A：RDS 只读实例是**复制整份数据**的异步副本，数据量越大、写入越猛，延迟越不可控，\"毫秒级\"不成立。\n  - ② 选 B：Redis 不适合做亿级明细的聚合分析，且数据模型与 SQL 分析能力不匹配。\n  - ③ 选 C：数据库代理的读一致性只能保证\"读己之写\"这一类会话级语义，**不能消除物理复制延迟**，属于概念混淆。\n- **延伸**：PolarDB 还有两个常考的衍生能力——**列存索引（IMCI）**：在行存之上建列存副本，走向量化执行引擎，适合大宽表聚合；**Serverless**：按 PCU 弹性伸缩，适合负载波动的场景。选型口诀：**\"要分析又要实时\"→ PolarDB（IMCI）；\"要极致弹性、按量付费\"→ Serverless；\"MySQL 生态零改造、成本优先\"→ RDS + 只读实例**。','2026-11-07 17:02:26',2,'中','active'),(248,NULL,16,'single','一个新业务即将上线，安全团队为其接入了 WAF，但担心内置规则误拦截正常请求导致用户无法下单。上线首周最稳妥的策略是？','{\"A\": \"直接关闭 WAF，等业务稳定后再接入\", \"B\": \"将防护模式设为**告警（观察）模式**，只记录命中日志不阻断流量；分析日志确认误报后，再切换为拦截模式\", \"C\": \"删除所有内置规则组，只保留自定义规则\", \"D\": \"把内置规则的优先级调到最低，让自定义规则优先生效\"}','B','- **考点**：WAF 的防护模式与灰度上线方法。WAF 通常提供**拦截模式**与**告警/观察模式**：后者对命中规则的请求只记录、不阻断，是\"先观测后收紧\"的标准做法。配合**日志查询**可以逐条确认是攻击还是误报，再针对误报添加白名单或关闭特定规则。\n- **易错点**：\n  - ① 选 A：不上 WAF 等于把风险敞口留给公网，且上线初期正是攻击高发期。\n  - ② 选 C：内置规则组是防护主体，删掉等于放弃大部分防护能力；正确做法是\"**精准加白**\"而不是\"整体删除\"。\n  - ③ 选 D：**自定义规则的优先级高于内置规则组**，这是固定设计，不需要\"调低内置规则优先级\"；而且优先级高低不解决误报，只影响谁先命中。\n- **延伸**：WAF 的规则调优三板斧——**误报加白（按 URL + 参数 + 规则 ID 精确放行）**、**针对业务接口配置精准防护（CC 防护、Bot 管理）**、**开启日志投递到 SLS 做长期分析**。另外要注意 WAF 只防七层，**四层 SYN Flood、UDP 反射**要靠 DDoS 防护，二者是互补关系而非替代。','2026-11-07 17:02:26',2,'中','active'),(249,NULL,17,'single','某公司的业务一部分部署在阿里云（使用 EIP），另一部分仍在自建 IDC（公网 IP 为运营商地址）。公司希望用一个统一方案为**全部公网 IP** 提供 DDoS 清洗能力。下列方案最合适的是？','{\"A\": \"为阿里云 EIP 购买 DDoS 原生防护，并把 IDC 的公网 IP 也加入该原生防护实例\", \"B\": \"使用云安全中心的 DDoS 防护模块覆盖全部 IP\", \"C\": \"购买 **DDoS 高防实例**，将 IDC 公网 IP 以非阿里云资产方式接入高防；阿里云内资产可按成本选择原生防护或直接接入高防\", \"D\": \"通过 WAF 即可同时抵御四层流量型攻击与七层应用层攻击\"}','C','- **考点**：DDoS 原生防护与 DDoS 高防的适用边界。**原生防护**是面向**阿里云内资产**（EIP、SLB、ECS 公网 IP 等）的 IP 级防护，开通即用、无需改变解析，但不能保护云外 IP；**高防实例**提供独立的**高防 IP**，通过 DNS 解析或 IP 映射把流量引到清洗中心，**支持非阿里云资产（IDC、其他云）接入**，并可选保底带宽、弹性带宽、回源线路。\n- **易错点**：\n  - ① 选 A：原生防护**只能绑定阿里云内的公网 IP**，IDC 的运营商地址加不进去，这是本题的核心判断点。\n  - ② 选 B：云安全中心是态势感知与主机/容器安全产品，不承担大流量清洗。\n  - ③ 选 D：WAF 工作在七层（HTTP/HTTPS），对 SYN Flood、UDP 反射这类**流量型攻击**无能为力。\n- **延伸**：接入高防后有两个必查项——**回源 IP 段要加入源站白名单**（否则清洗后的流量被源站安全组拦掉），以及**真实客户端 IP 的获取方式**（高防会改写源 IP，需从 `X-Forwarded-For` 或 PROXY Protocol 取）。另外，\"清洗阈值\"设得过低会误清洗正常突发流量，需要结合业务基线调优；超过实例防护能力后仍会触发**黑洞**，因此保底带宽要按历史攻击峰值选型。','2026-11-07 17:02:26',2,'中','active'),(250,NULL,18,'single','合规要求：运维人员只能从公司办公网（`203.0.113.0/24`）登录阿里云控制台，但 CI/CD 流水线使用的 AccessKey 必须能从任意 IP 调用 API。下列配置最合理的是？','{\"A\": \"为 RAM 用户绑定一个只允许办公网访问的安全组\", \"B\": \"开启 MFA 并配置登录掩码；登录掩码会同时限制该用户 AccessKey 调用 API 的来源 IP\", \"C\": \"使用资源目录的管控策略限制成员账号的登录地域\", \"D\": \"为 RAM 用户配置**登录掩码**为办公网网段；登录掩码**只限制控制台登录**，不影响 AccessKey 调用 API\"}','D','- **考点**：RAM 登录掩码的作用范围。**登录掩码（Login Mask）**用于限制 RAM 用户**登录控制台**的源 IP（可配置多个网段，支持 IPv4/IPv6），超出范围的登录会被拒绝；它**不约束 API 调用**（AccessKey/STS），因此正好满足\"控制台限办公网、流水线任意 IP 调 API\"的需求。\n- **易错点**：\n  - ① 选 A：安全组是网络层的实例防火墙，与\"控制台登录\"完全无关，属于跨域混淆。\n  - ② 选 B：登录掩码不限制 API；如果确实要限制 API 来源，应使用 **RAM 的\"访问控制\"条件（`acs:SourceIp`）** 或 **网络型管控（如 VPC 端点/PrivateLink 调用 OpenAPI）**。另外 MFA 是\"多因子认证\"，解决的是\"凭证被盗\"，不是\"来源限制\"。\n  - ③ 选 C：管控策略（Control Policy）限制的是成员账号内可用的**服务与操作范围**，不是登录 IP。\n- **延伸**：纵深防御的组合拳是——**登录掩码（控制台来源） + MFA（身份强度） + 最小权限 RAM Policy（能做什么） + AccessKey 轮转/改用 RAM 角色 STS（凭证生命周期） + ActionTrail（事后审计）**。特别注意：**主账号 AccessKey 应禁用**，且登录掩码对主账号不生效，主账号只能靠 MFA 与\"仅邮箱登录\"来加固。','2026-11-07 17:02:26',2,'中','active'),(251,NULL,19,'single','某公司要求：ECS 上 `/data/app` 目录的配置文件与日志，需保留 **1 年**并可**跨地域**恢复，同时希望能按文件粒度快速找回单个误删文件。最合适的方案是？','{\"A\": \"使用**云备份 HBR** 对该目录做文件备份，设置长周期保留策略；同时开启**备份库跨地域复制**，实现异地容灾\", \"B\": \"依赖 ECS 自动快照，把快照保留天数直接设为 365 天\", \"C\": \"每天为实例创建一份自定义镜像，保留一年\", \"D\": \"通过 OSS 生命周期规则把快照转为归档存储，降低成本\"}','A','- **考点**：云备份 HBR 与 ECS 快照的能力差异。**快照**是**块设备级**、**地域内**、以云盘为单位的备份，适合整机/整盘回滚，但**不能跨地域**、**不能按文件恢复**（需先创建云盘再挂载才能取文件）；**HBR 文件备份**通过客户端做**文件级**备份，支持**按文件/目录恢复**、**长周期保留**、**备份库跨地域复制**与**异地恢复**，正好覆盖本题三个诉求。\n- **易错点**：\n  - ① 选 B：自动快照保留天数可调，但快照仍受\"**地域内**\"和\"**不支持文件级恢复**\"两条硬限制，且 365 天全量快照的存储成本很高。\n  - ② 选 C：自定义镜像包含整块系统盘，体积大、创建慢，用来做\"文件版本管理\"成本与效率都不合适。\n  - ③ 选 D：快照是独立的块存储服务，**不能**被 OSS 生命周期规则处理；OSS 生命周期只作用于 OSS 内的对象。\n- **延伸**：备份方案要回答四个问题——**RPO（多久备份一次）**、**RTO（多久能恢复）**、**保留期**、**隔离性（能否抵御勒索/误删）**。HBR 支持**备份锁定（WORM）**与**跨账号备份**，可防\"管理员把备份一起删了\"。另外，**ECS 整机备份**底层仍依赖快照，但由 HBR 统一管理生命周期，适合\"整机快速重建 + 长期保留\"的组合场景。','2026-11-07 17:02:26',2,'中','active'),(252,NULL,20,'single','基础设施通过 ROS 资源栈统一管理。某天同事在控制台手工调大了 RDS 实例规格，导致模板与实际资源不一致，后续用模板更新资源栈时出现异常。要**发现**这类\"配置漂移\"最合适的做法是？','{\"A\": \"直接重新执行资源栈\\\"更新\\\"，模板会自动把控制台改动覆盖回来，无需检测\", \"B\": \"使用 ROS 的**偏差检测（Drift Detection）**，比对模板声明的期望状态与资源实际状态，列出被手工修改的资源及具体属性\", \"C\": \"为资源栈开启**保护策略**，即可阻止任何控制台修改\", \"D\": \"查询 ActionTrail 操作日志即可自动把资源恢复为模板状态\"}','B','- **考点**：IaC 的\"配置漂移\"治理。ROS 资源栈维护的是\"模板 → 资源\"的映射，但资源本身仍可被控制台、API、其他工具修改，形成**漂移（Drift）**。ROS 提供**偏差检测**能力，逐个资源比对各属性的期望值与实际值，输出\"已修改/已删除\"的资源清单与属性差异，是排查\"为什么更新失败/为什么环境和代码不一致\"的入口。\n- **易错点**：\n  - ① 选 A：更新操作只处理**模板中声明的变更**，而且遇到\"不支持更新的属性\"会走**替换（重建）**，可能造成中断；它不会主动告诉你\"哪里被改了\"，也不适用于\"先发现后决策\"的流程。\n  - ② 选 C：**保护策略（Protection）**只防止资源被**删除**，不阻止修改。\n  - ③ 选 D：ActionTrail 只记录\"谁在什么时候做了什么\"，是**审计**而非**状态比对**，不会自动回滚。\n- **延伸**：治理漂移的完整闭环是——**偏差检测发现问题 → 决定\"以代码为准\"（更新资源栈覆盖）还是\"以现状为准\"（回写模板）→ 用 CI 流水线把 Terraform/ROS 变更纳入评审 → 用管控策略限制高风险控制台操作**。另外，ROS 更新时区分 **NoInterruption / SomeInterruption / Disruption** 三类影响，生产环境建议先 **`Preview`（询价/预检）** 再执行，并对关键资源加保护策略。','2026-11-07 17:02:26',2,'中','active');
/*!40000 ALTER TABLE `questions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `quiz_records`
--

DROP TABLE IF EXISTS `quiz_records`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `quiz_records` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int unsigned NOT NULL,
  `category_id` int unsigned NOT NULL,
  `cert_path` varchar(160) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `cert_name` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `question_ids` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `answers` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `total` int NOT NULL DEFAULT '0',
  `correct` int NOT NULL DEFAULT '0',
  `score` int NOT NULL DEFAULT '0',
  `accuracy` decimal(5,4) NOT NULL DEFAULT '0.0000',
  `duration` int NOT NULL DEFAULT '0',
  `started_at` varchar(19) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `finished_at` varchar(19) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_qr_user` (`user_id`,`finished_at`),
  KEY `idx_qr_cat` (`category_id`,`finished_at`),
  KEY `idx_qr_time` (`finished_at`),
  CONSTRAINT `fk_qr_category` FOREIGN KEY (`category_id`) REFERENCES `cert_categories` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_qr_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='每日答题记录';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `quiz_records`
--

LOCK TABLES `quiz_records` WRITE;
/*!40000 ALTER TABLE `quiz_records` DISABLE KEYS */;
INSERT INTO `quiz_records` VALUES (1,2,2,'aliyun/acp/cloud','阿里云ACP云计算高级工程师','[93, 97, 101, 95, 96, 100, 98, 99, 94, 102]','{\"93\": [\"A\"], \"97\": [\"A\"], \"101\": [\"A\"], \"95\": [\"A\"], \"96\": [\"A\"], \"100\": [\"A\"], \"98\": [\"A\"], \"99\": [\"A\"], \"94\": [\"A\"], \"102\": [\"A\"]}',10,4,40,0.4000,66,'','2026-11-07 00:02:14');
/*!40000 ALTER TABLE `quiz_records` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rankings`
--

DROP TABLE IF EXISTS `rankings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `rankings` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `period_type` varchar(8) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'day/week/month',
  `period_key` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '2026-11-06 / 2026-W45 / 2026-11',
  `user_id` int unsigned NOT NULL,
  `points` int NOT NULL DEFAULT '0',
  `quiz_count` int NOT NULL DEFAULT '0',
  `best_score` int NOT NULL DEFAULT '0',
  `updated_at` varchar(19) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_rank` (`period_type`,`period_key`,`user_id`),
  KEY `idx_rank_query` (`period_type`,`period_key`,`points`),
  KEY `fk_rank_user` (`user_id`),
  CONSTRAINT `fk_rank_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='排行榜积分汇总';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rankings`
--

LOCK TABLES `rankings` WRITE;
/*!40000 ALTER TABLE `rankings` DISABLE KEYS */;
INSERT INTO `rankings` VALUES (1,'day','2026-11-07',2,40,1,40,'2026-11-07 00:02:14'),(2,'week','2026-W45',2,40,1,40,'2026-11-07 00:02:14'),(3,'month','2026-11',2,40,1,40,'2026-11-07 00:02:14');
/*!40000 ALTER TABLE `rankings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sms_codes`
--

DROP TABLE IF EXISTS `sms_codes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sms_codes` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int unsigned NOT NULL,
  `phone` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `purpose` varchar(24) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'bind_phone',
  `code_hash` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `expires_at` varchar(19) COLLATE utf8mb4_unicode_ci NOT NULL,
  `attempts` int NOT NULL DEFAULT '0',
  `used` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` varchar(19) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_sms_user` (`user_id`,`purpose`,`created_at`),
  CONSTRAINT `fk_sms_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='短信验证码';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sms_codes`
--

LOCK TABLES `sms_codes` WRITE;
/*!40000 ALTER TABLE `sms_codes` DISABLE KEYS */;
INSERT INTO `sms_codes` VALUES (2,2,'13800001234','bind_phone','5f6124e476c329a351c1cd596ff2ffea90be6ac7f56a8923e89bbb3bcc0a9870','2026-11-07 13:12:40',0,1,'2026-11-07 13:02:40');
/*!40000 ALTER TABLE `sms_codes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_honors`
--

DROP TABLE IF EXISTS `user_honors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_honors` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int unsigned NOT NULL,
  `category_id` int unsigned NOT NULL,
  `cert_name` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `score` int NOT NULL DEFAULT '0',
  `correct` int NOT NULL DEFAULT '0',
  `total` int NOT NULL DEFAULT '0',
  `duration` int NOT NULL DEFAULT '0',
  `quiz_date` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` varchar(19) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_uh_user` (`user_id`,`created_at`),
  KEY `idx_uh_date` (`quiz_date`),
  KEY `fk_uh_category` (`category_id`),
  CONSTRAINT `fk_uh_category` FOREIGN KEY (`category_id`) REFERENCES `cert_categories` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_uh_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='个人荣誉流水';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_honors`
--

LOCK TABLES `user_honors` WRITE;
/*!40000 ALTER TABLE `user_honors` DISABLE KEYS */;
INSERT INTO `user_honors` VALUES (1,2,2,'阿里云ACP云计算高级工程师',40,4,10,66,'2026-11-07','2026-11-07 00:02:14');
/*!40000 ALTER TABLE `user_honors` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password_hash` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `role` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'user',
  `created_at` varchar(19) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nickname` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `gender` varchar(8) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '保密',
  `bio` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `phone` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone_verified` tinyint(1) NOT NULL DEFAULT '0',
  `email` varchar(128) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email_verified` tinyint(1) NOT NULL DEFAULT '0',
  `reset_token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `reset_token_expire_at` varchar(19) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `updated_at` varchar(19) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_users_username` (`username`),
  UNIQUE KEY `uk_users_phone` (`phone`),
  UNIQUE KEY `uk_users_email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (2,'user','pbkdf2:sha256:1000000$g7Rq9mmHwhxNahtq$fc6c9f926e00fd296b627be267ea52cb0866868ec2b710f1365ebb3796eaf228','user','2026-11-06 21:07:42','','保密','','13800001234',1,'user@example.com',1,'51851b85cecca40307da9215399e5b4b7b179a518f1103fa49a62c3ea71d30ce','2026-11-07 13:37:41','2026-11-07 13:02:40'),(21,'lucas','pbkdf2:sha256:1000000$dH5t5xb7pyI56ADu$e220332f80f2bc33a717d6109538484a509f948f554ccc11dc186fc5d5beda33','user','2026-11-07 17:00:19','','保密','',NULL,0,'lucas@bifen.win',0,'','','');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wrong_questions`
--

DROP TABLE IF EXISTS `wrong_questions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `wrong_questions` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `daily_set_id` int unsigned NOT NULL,
  `question_id` int unsigned NOT NULL,
  `user_id` int unsigned NOT NULL DEFAULT '0',
  `user_answer` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `correct_answer` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` varchar(19) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_wrong_question_user` (`question_id`,`user_id`),
  KEY `idx_wrong_set` (`daily_set_id`),
  KEY `idx_wrong_user` (`user_id`),
  CONSTRAINT `fk_wrong_question` FOREIGN KEY (`question_id`) REFERENCES `questions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_wrong_set` FOREIGN KEY (`daily_set_id`) REFERENCES `daily_sets` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_wrong_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wrong_questions`
--

LOCK TABLES `wrong_questions` WRITE;
/*!40000 ALTER TABLE `wrong_questions` DISABLE KEYS */;
/*!40000 ALTER TABLE `wrong_questions` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-11-07 18:14:54
